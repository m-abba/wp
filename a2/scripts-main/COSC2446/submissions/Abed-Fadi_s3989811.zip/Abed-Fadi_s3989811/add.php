<?php 

include("includes/db_connect.inc");

if ($_SERVER['REQUEST_METHOD'] == 'POST'  ) {
    $uploadDir = 'images/';
    
$file=null;
     //we will give the image a unique file name so we prevent replacing existing image if uploaded with the same name
    if (isset($_FILES['img']) && $_FILES['img']['error'] == UPLOAD_ERR_OK) {
        $originalName = basename($_FILES['img']['name']);
        $uniqueName = date('YmdHis') .'_' . $originalName;
        $uploadFile = $uploadDir . $uniqueName;

        move_uploaded_file($_FILES['img']['tmp_name'], $uploadFile);
        $file=$uniqueName;
    }
 $petname = $_POST['fname'];
 $description = $_POST['desc'];
  $caption = $_POST['caption'];
 $age = $_POST['age'];
 $location = $_POST['location'];
 $type = $_POST['type'];
   $insert_ = "INSERT into pets(	petname,description,image,caption,age,location,type) values (?,?,?,?,?,?,?)";
   $query = mysqli_prepare($conn,$insert_);
    $query->bind_param("sssssss",$petname,$description,$file,$caption,$age,$location,$type);
   
$result = $query->execute();

if($result){
header("location:add.php?msg=A new record was added successfully");
}else{
header("location:add.php?msg=Error please try again");
}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<title>Add PETS </title>
<?php include('includes/header.inc'); ?>
</head>

<body>

<?php include('includes/nav.inc') ?>
<?php if(isset($_GET['msg'])){
    echo "<h3 style='text-align:center'>".$_GET['msg']."</h3>";
    
}else{
    ?>
    <section class="add_pet_sec">
    <br><br>
        <h3>
            Add a pet
        </h3>
        <p>You can add a new pet here</p>
        <form method="POST" action="add.php" enctype="multipart/form-data">
            <label for="fname" style="margin-top: 20px;">pet name:
                <span>⁎</span>
            </label>
            <input type="text" id="fname" required name="fname" placeholder="Provide a name for the pet">
            <label for="type">type:<span>⁎</span></label>
            <select name="type" id="type" required>
                <option   disabled  value="" selected>--Choose an option--</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
            </select>
            <label for="desc">description:<span>⁎</span></label>
            <textarea id="desc" required name="desc" rows="2" placeholder="Describe the pet briefly"></textarea>
            <label for="img">select an image:<span>⁎</span></label>
            <input type="file" id="img" name="img" required>
            <span class="img_size">max image size: 500px</span><br>
            <label for="caption">image caption:<span>⁎</span></label>
            <input type="text" required id="caption" name="caption" placeholder="describe the image in one word">
            <label for="age">age (months):<span>⁎</span></label>
            <input type="number" required step="any" id="age" name="age" placeholder="Age of a pet in months">
            <label for="location">location:<span>⁎</span></label>
            <input type="text" id="location" required name="location" placeholder="Location of the pet">
            <div class="btns">
                <button type="submit"><span class="material-symbols-outlined add_task">
                    add_task
                    </span> Submit</button>
                <button type="reset"><span class="material-symbols-outlined clear">
                    close
                    </span>clear</button>
            </div>

          </form> 
    </section>
    <?php }?>
    <?php include('includes/footer.inc') ?>

</body>
</html>