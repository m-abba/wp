 <!DOCTYPE html>
<html lang="en">

<head>
<?php include('includes/header.inc')?>
<title>PETS - PETS VICTORIA</title>

</head>

<body>

<?php include('includes/nav.inc') ?>

    <section class="pets_sec">
        <h3>Discover Pets Victoria</h3>
        <p>
            Pets Victoria is a dedicated pet adoption organization based in Victoria, Australia, focused on Providing a safe and loving environment for pets in need. With a compassionate approach, Pets Victoria works tirelessly to rescue, rehabilitate, and rehome dogs,cats and other animals. Their mission is to connect these deserving pets with caring individuals and families, creating lifelong bonds. The organization offers a range of services, including adoption counseling, pet education, and community support programs, all aimed at promoting responsible pet ownership and reducing the number of homeless animals.
        </p>
        <div class="flex">
          <div class="pets_img">
            <img src="./images/pets.jpeg" alt="">
        </div>
        <div class="pets_table">
            <table>
              <thead>
                <tr>
                  <th>Pet</th>
                  <th>Type</th>
                  <th>Age</th>
                  <th>Location</th>
                </tr>
            </thead>
            <tbody>
              <?php include("includes/db_connect.inc");
              if(isset($_GET['search'])){
                $sql = "SELECT * from pets where petname like ? ;" ;
                $searchTerm = '%' . $_GET['search'] . '%';

                $query = mysqli_prepare($conn,$sql);
                $query->bind_param("s",$searchTerm);
                $query->execute();
                $result = $query->get_result();
                $pets = $result->fetch_all(MYSQLI_ASSOC);
               }else{
                $sql = "SELECT * from pets order by petid;" ;
                $pets = mysqli_query($conn, $sql);
              }
            
      foreach ($pets as $pet ) {
?>
    <tr>
                  <td><a href="details.php?id=<?php echo $pet['petid']?>"><?php echo $pet['petname']?></a></td>
                  <td><?php echo $pet['type']?></td>
                  <td><?php      if ($pet['age'] >= 12) {
        $years = $pet['age'] / 12;
        echo number_format($years, 1) . ' Years';
    } else {
        echo $pet['age'] . ' Months';
    } ?> </td>
                  <td><?php echo $pet['location']?></td>
                </tr>

<?php }?>
            </tbody>
              </table>
              
        </div>
        </div>
  
      
    </section>

    <?php include('includes/footer.inc') ?>

</body>
</html>