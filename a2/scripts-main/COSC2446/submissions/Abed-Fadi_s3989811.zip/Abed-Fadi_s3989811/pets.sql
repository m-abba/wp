-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 02, 2024 at 04:14 PM
-- Server version: 8.3.0
-- PHP Version: 8.1.28
SET
  SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

START TRANSACTION;

SET
  time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;

/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;

/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;

/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petsvictoria`
--
-- --------------------------------------------------------
--
-- Table structure for table `pets`
--
DROP TABLE IF EXISTS `pets`;

CREATE TABLE
  IF NOT EXISTS `pets` (
    `petid` int NOT NULL AUTO_INCREMENT,
    `petname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
    `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
    `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
    `caption` varchar(255) CHARACTER
    SET
      utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
      `age` double NOT NULL,
      `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
      `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
      PRIMARY KEY (`petid`)
  ) ENGINE = MyISAM AUTO_INCREMENT = 13 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

--
-- Dumping data for table `pets`
--
INSERT INTO
  `pets` (
    `petid`,
    `petname`,
    `description`,
    `image`,
    `caption`,
    `age`,
    `location`,
    `type`
  )
VALUES
  (
    10,
    'Oliver',
    'a playful and curious cat with a love for adventure and a gentle, affectionate nature.',
    '20240901162757_cat4.jpeg',
    'any',
    12,
    'GRAMPIANS',
    'cat'
  ),
  (
    9,
    'Willow',
    'a loyal and energetic dog, always eager for outdoor fun and quick to offer comfort with her warm, friendly personality.',
    '20240901162646_dog2.jpeg',
    'any',
    48,
    'MARYSVILLE',
    'dog'
  ),
  (
    7,
    'Baxter',
    'a cheerful and intelligent dog, known for his boundless energy and deep affection for his family.',
    '20240901162540_dog1.jpeg',
    'any',
    5,
    'CAPE WOOLAMAI',
    'dog'
  ),
  (
    8,
    'Luna',
    ' a charming and playful cat, often seen basking in sunlight and delighting everyone with her whimsical antics.',
    '20240901162603_cat2.jpeg',
    'any',
    1,
    'FERNTREE GULLY',
    'cat'
  ),
  (
    6,
    'Milo',
    'a mischievous and playful cat, known for his adventurous spirit and knack for finding the coziest spots to nap.',
    '20240901162507_cat1.jpeg',
    'any',
    3,
    'MELBOURNE CBD',
    'cat'
  ),
  (
    11,
    'Bella',
    'a friendly and affectionate dog, always ready to greet everyone with her wagging tail and warm, loving nature.',
    '20240901162818_dog3.jpeg',
    'any',
    10,
    'Carlton',
    'dog'
  );

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;

/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;