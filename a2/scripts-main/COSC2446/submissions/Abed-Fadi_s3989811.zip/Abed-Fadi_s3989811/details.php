<!DOCTYPE html>
<html lang="en">

<head>

<?php include('includes/header.inc')?>
<title>PETS - PETS VICTORIA</title>

</head>
<body>

<?php include('includes/nav.inc');
include('includes/db_connect.inc');

// Check if 'id' is set in the query string
if (isset($_GET['id'])) {
    // Sanitize the input to ensure it's an integer
    $petid = intval($_GET['id']);  // Convert to integer

    // Prepare the SQL statement to prevent SQL injection
    if ($query = mysqli_prepare($conn, "SELECT * FROM pets WHERE petid = ?")) {
        // Bind the parameter as an integer
        $query->bind_param("i", $petid);
        
        // Execute the prepared statement
        $query->execute();
        
        // Get the result of the query
        $result = $query->get_result();
        
        // Fetch the associative array
        $pet = $result->fetch_assoc();
        
        // Free result set and close the statement
        $query->close();
    } else {
        echo "Error in preparing the SQL statement.";
    }
} else {
    echo "No pet ID provided.";
}
?>

    <section class="pets_sec">
         
        <div class=" " style="width: 100%;">
          <div class="pets_img">
            <center>
            <img src="./images/<?php echo $pet['image'] ?>" style="margin: auto;" alt="<?php echo $pet['petname'] ?>">

            </center>
        
            <table style="width: 100%;text-align: center;border: 0;" border="0">
                 <tr>
                  <td style="width: 33.33%;">
                    <img src="images/clock.png" width="50px" style="margin: auto;" alt="">
                <br>  <?php echo $pet['age'] ?>
                  </td>
                  <td style="width: 33.33%;">
                  <img src="images/pawprint.png" width="50px" style="margin: auto;" alt="">

                  <br>   <?php echo $pet['type'] ?>
                  </td>
                  <td style="width: 33.33%;">
                  <img src="images/location.png" width="50px" style="margin: auto;" alt="">

                  <br>  <?php echo $pet['location'] ?>
                  </td>
                </tr>

              </table>
              <br><br>
              <h1 style="text-align: center;"><?php echo $pet['petname'] ?></h1>
              <p>
              <?php echo $pet['description'] ?>
              </p>
        </div>
        </div>
  
      
    </section>

    <?php include('includes/footer.inc') ?>

</body>
</html>