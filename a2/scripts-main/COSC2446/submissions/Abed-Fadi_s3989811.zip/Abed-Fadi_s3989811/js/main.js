function navigateToPage(){
    let selectElement = document.getElementById("selectedPage");
    let val = selectElement.value;

    if (val){
        window.location.href = `./${val}`;
    }
}