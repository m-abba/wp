<!DOCTYPE html>
<html lang="en">

<head>
<?php include('includes/header.inc')?>
<title>Home - PETS VICTORIA</title>

</head>
<body>

    <section>
        
    <?php include('includes/nav.inc') ?>
        <div class="main_content">
            <div class="content">
                <h1>PETS VICTORIA</h1>
                <h2>WELCOME TO PET ADOPTION</h2>
            </div>
            <div class="main_img">
                <img src="./images/main.jpg" alt="">
            </div>
        </div>
    </section>
    <?php include('includes/footer.inc') ?>
</body>

</html>