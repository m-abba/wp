 <!DOCTYPE html>
<html lang="en">

<head>

<?php include('includes/header.inc')?>
<title>Gallery PETS</title>

</head>
<body>

<?php include('includes/nav.inc') ?>

    <section class="gallery_sec">
        <h3>Pets Victoria has a lot to offer!</h3>
        <p class="gallery_p">
            For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption into the mainstream. Our work has helped make a difference to the Victorian rescue community and thousands of pets in need of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we all still have big, hairy work to do.
        </p>
        <div class="cards" >
        <?php include("includes/db_connect.inc");
              $sql = "SELECT * from pets order by petid ;" ;
              $pets = mysqli_query($conn, $sql);
      foreach ($pets as $pet ) {
?>
            <div class="card">
                <div class="img">
                    <img src="./images/<?php echo $pet['image'] ?>" style="margin: auto;height: 250px;" alt="<?php echo $pet['petname'] ?>">
                </div>
                <div class="learn_more">
                        <span class="material-symbols-outlined">
                            search
                        </span>

                    <a href="details.php?id=<?php echo $pet['petid']?>">DISCOVER MORE!</a>
                </div>
                <h3><?php echo $pet['petname'] ?></h3>
            </div>
            <?php } ?>
         
            
          
           
        </div>
    </section>
    <?php include('includes/footer.inc') ?>

</body>
</html>