<?php include 'includes/header.inc'; ?>
<?php include 'includes/nav.inc'; ?>
<?php include 'includes/db_connect.inc'; ?>

<!-- Wrapper for the 1200px width -->
<div class="container">
    <main class="pet-detail">
        <section class="pet-details">
            <?php
            // Get the pet ID from the query string
            if (isset($_GET['id'])) {
                $petid = $_GET['id'];

                // Use prepared statements to prevent SQL injection
                $stmt = $conn->prepare("SELECT * FROM pets WHERE petid = ?");
                $stmt->bind_param("i", $petid);
                $stmt->execute();
                $result = $stmt->get_result();

                // Check if the pet exists
                if ($row = $result->fetch_assoc()) {
                    $petname = $row['petname'];
                    $description = $row['description'];
                    $age = $row['age'];
                    $type = isset($row['type']) ? $row['type'] : 'Unknown'; // Fallback if 'type' is undefined
                    $location = $row['location'];
                    $image = $row['image'] ? $row['image'] : 'placeholder.jpg'; // Use placeholder if no image
                    $caption = $row['caption'];

                    echo "
        <div class='pet-header'>
            <img class='pet-image' src='images/{$image}' alt='{$caption}'>
        </div>
        <div class='pet-info'>
            <div class='pet-attributes'>
                <span class='attribute'><i class='material-symbols-outlined'>alarm</i> {$age} months</span>
                <span class='attribute'><i class='material-symbols-outlined'>pets</i> {$type}</span>
                <span class='attribute'><i class='material-symbols-outlined'>location_on</i> {$location}</span>
            </div>
            <h4>{$petname}</h4>
            <p class='description'>{$description}</p>
        </div>
        "; // Closing all divs opened inside this block
                } else {
                    echo "<p>Pet not found.</p>";
                }
                $stmt->close();
            } else {
                echo "<p>No pet ID specified.</p>";
            }
            ?>
        </section> <!-- Correctly closing the section here -->
    </main>
</div> <!-- End of the container -->

<?php include 'includes/footer.inc'; ?>