<?php include 'includes/header.inc'; ?>
<?php include 'includes/nav.inc'; ?>
<?php include 'includes/db_connect.inc'; ?>

<main>
    <section class="pets-section">
       <h3>Pets Victoria has a lot to offer!</h3>
        <p>
            For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption
            into the mainstream. Our work has helped make a difference to the Victorian rescue community and
            thousands of pets in need of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we still have a lot of work to do.
        </p>

        <div class="gallery-grid">
            <!-- Dynamic pet entries from the database -->
            <?php
            // Fetch all pets added via the form/database
            $query = "SELECT petid, petname, image, caption FROM pets";
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $petid = $row['petid'];
                    $petname = $row['petname'];
                    $image = $row['image'] ? $row['image'] : 'placeholder.jpg'; // Use placeholder if image not found
                    $caption = $row['caption'];

                    echo "
                    <div class='pet'>
                        <a href='details.php?id={$petid}'>
                            <img src='images/{$image}' alt='{$caption}'>
                            <div class='pet-overlay'>
                                <i class='fa fa-search'></i>
                                <span>Discover more!</span>
                            </div>
                        </a>
                        <div class='pet-name'>{$petname}</div>
                    </div>
                    ";
                }
            } else {
                echo "<p>No new pets added yet.</p>";
            }
            ?>
        </div>
    </section>
</main>

<?php include 'includes/footer-gallery.inc'; ?>
