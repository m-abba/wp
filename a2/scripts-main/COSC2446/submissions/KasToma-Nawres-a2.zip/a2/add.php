<?php
include 'includes/db_connect.inc'; // Include your database connection file

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the form data
    $petName = $_POST['petName'];
    $type = $_POST['type'];
    $description = $_POST['description'];
    $imageCaption = $_POST['imageCaption'];
    $age = $_POST['age'];
    $location = $_POST['location'];

    // Handle the file upload
    $image = $_FILES['file-input']['name'];
    $target = "images/" . basename($image);
    move_uploaded_file($_FILES['file-input']['tmp_name'], $target);

    // Prepare SQL statement to insert data
    $sql = "INSERT INTO pets (petname, description, caption, age, type, location, image) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssisss", $petName, $description, $imageCaption, $age, $type, $location, $image);

    // Execute the SQL query
    if ($stmt->execute()) {
        echo "<p class='success-message'>New pet added successfully!</p>";
    } else {
        echo "<p class='error-message'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
    $conn->close();
}
?>

<?php include 'includes/header.inc'; ?>
<?php include 'includes/nav.inc'; ?>

<h1 class="add-pet-heading">Add a pet</h1>
<p class="add-pet-subheading">You can add a new pet here</p>

<form action="add.php" method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label for="petName">PET NAME:<span class="required-asterisk">*</span></label>
        <input type="text" id="petName" name="petName" placeholder="Enter pet's name" required>
    </div>

    <div class="form-group">
        <label for="type">TYPE:<span class="required-asterisk">*</span></label>
        <select id="type" name="type" required>
            <option value="">--Choose an option--</option>
            <option value="Cat">Cat</option>
            <option value="Dog">Dog</option>
            <option value="Bird">Bird</option>
            <option value="Rabbit">Rabbit</option>
            <option value="Fish">Fish</option>
            <option value="Hamster">Hamster</option>
            <option value="Turtle">Turtle</option>
            <option value="Lizard">Lizard</option>
            <option value="Snake">Snake</option>
            <option value="Horse">Horse</option>
            <option value="Guinea Pig">Guinea Pig</option>
            <option value="Frog">Frog</option>
            <option value="Ferret">Ferret</option>
            <option value="Chicken">Chicken</option>
            <option value="Goat">Goat</option>
            <option value="Pig">Pig</option>
        </select>
    </div>

    <div class="form-group">
        <label for="description">DESCRIPTION:<span class="required-asterisk">*</span></label>
        <textarea id="description" name="description" placeholder="Describe the pet briefly" required></textarea>
    </div>

    <div class="image-upload">
        <label for="file-input">SELECT AN IMAGE:<span class="required-asterisk">*</span></label>
        <input id="file-input" type="file" name="file-input" required>
        <span class="image-size-info">max image size: 500px</span>
    </div>

    <div class="form-group">
        <label for="imageCaption">IMAGE CAPTION:<span class="required-asterisk">*</span></label>
        <input type="text" id="imageCaption" name="imageCaption" placeholder="Describe the image in one word" required>
    </div>

    <div class="form-group">
        <label for="age">AGE (MONTHS):<span class="required-asterisk">*</span></label>
        <input type="number" id="age" name="age" placeholder="Age of the pet in months" required>
    </div>

    <div class="form-group">
    <label for="location">LOCATION:<span class="required-asterisk">*</span></label>
    <input type="text" id="location" name="location" placeholder="Enter or get location" required>
</div>


    <button type="submit" class="submit-button">submit</button>
    <button type="reset" class="clear-button">clear</button>
</form>

<?php include 'includes/footer.inc'; ?>
