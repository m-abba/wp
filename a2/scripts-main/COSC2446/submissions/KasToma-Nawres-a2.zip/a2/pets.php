<?php include 'includes/header.inc'; ?>
<?php include 'includes/nav.inc'; ?>

<main>
    <h1 class="petsvic">Discover Pets Victoria</h1>

    <p class="pets-para">PETS VICTORIA IS A DEDICATED PET ADOPTION ORGANIZATION BASED IN VICTORIA, AUSTRALIA, FOCUSED ON PROVIDING A SAFE AND LOVING ENVIRONMENT FOR PETS IN NEED. WITH A COMPASSIONATE APPROACH, PETS VICTORIA WORKS TIRELESSLY TO RESCUE, REHABILITATE, AND REHOME DOGS, CATS, AND OTHER ANIMALS. THEIR MISSION IS TO CONNECT THESE DESERVING PETS WITH CARING INDIVIDUALS AND FAMILIES, CREATING LIFELONG BONDS. THE ORGANIZATION OFFERS A RANGE OF SERVICES, INCLUDING ADOPTION COUNSELING, PET EDUCATION, AND COMMUNITY SUPPORT PROGRAMS, ALL AIMED AT PROMOTING RESPONSIBLE PET OWNERSHIP AND REDUCING THE NUMBER OF HOMELESS ANIMALS.</p>
    
    <div class="image-container">
        <img src="images/pets.jpeg" alt="Running Dogs">
    </div>

    <table class="pet-table">
        <thead>
            <tr>
               <th>Pet</th>
                <th>Type</th>
                <th>Age</th>
                <th>Location</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include 'includes/db_connect.inc'; // Include your database connection file

            // Fetch pets data from the database
            $sql = "SELECT petid, petname, type, age, location, image FROM pets";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Loop through each pet and display its details in the table
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td><a class='pet-name' href='details.php?id=" . urlencode($row['petid']) . "'>" . htmlspecialchars($row['petname']) . "</a></td>";
                    echo "<td>" . htmlspecialchars($row['type']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['age']) . " months</td>";
                    echo "<td>" . htmlspecialchars($row['location']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No pets available.</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>
</main>

<?php include 'includes/footer.inc'; ?>
