<?php
include 'includes/header.inc';
include 'includes/' ?>
<h1 class='add-pet-heading'>Add a pet</h1>
<p class='add-pet-subheading'>You can add a new pet here</p>

<form action='#'>
    <div class='form-group'>
        <label for='petName'>PET NAME:<span class='required-asterisk'>*</span></label>
        <input type='text' id='petName' placeholder='Enter pet' s name'>
    </div>
    <div class='form-group'>
        <label for='type'>TYPE:<span class='required-asterisk'>*</span></label>
        <select id='type'>
            <option value=''>--Choose an option--</option>
            <!-- Add more options here -->
        </select>
    </div>
    <div class='form-group'>
        <label for='description'>DESCRIPTION:<span class='required-asterisk'>*</span></label>
        <textarea id='description' placeholder='Describe the pet briefly'></textarea>
    </div>
    <div class='image-upload'>
        <label for='file-input'>SELECT AN IMAGE:<span class='required-asterisk'>*</span></label>
        <input id='file-input' type='file'>
        <span class='image-size-info'>max image size: 500px</span>
    </div>
    <div class='form-group'>
        <label for='imageCaption'>IMAGE CAPTION:<span class='required-asterisk'>*</span></label>
        <input type='text' id='imageCaption' placeholder='Describe the image in one word'>
    </div>
    <div class='form-group'>
        <label for='age'>AGE (MONTHS):<span class='required-asterisk'>*</span></label>
        <input type='number' id='age' placeholder='Age of a pet in months'>
    </div>
    <div class='form-group'>
        <label for='location'>LOCATION:<span class='required-asterisk'>*</span></label>
        <input type='text' id='location' placeholder='Location of the pet'>
    </div>
    <button type='submit' class='submit-button'>
        <svg xmlns='http://www.w3.org/2000/svg' height='20px' viewBox='0 -960 960 960' width='20px' fill='#e8eaed'>
            <path
                d='M480-96q-79.38 0-149.19-30T208.5-208.5Q156-261 126-330.96t-30-149.5Q96-560 126-629.5q30-69.5 82.5-122T330.81-834q69.81-30 149.19-30 63 0 120 19t105 54l-52 52q-37-26-81-39.5T480-792q-129.67 0-220.84 91.23-91.16 91.23-91.16 221Q168-350 259.16-259q91.17 91 220.84 91 36.87 0 71.43-8Q586-184 617-199l53 53q-42 24-89.91 37Q532.17-96 480-96Zm264-72v-120H624v-72h120v-120h72v120h120v72H816v120h-72ZM425-307 264-468l52-52 110 110 387-387 51 51-439 439Z' />
        </svg>
        submit
    </button>
    <button type='reset' class='clear-button'>
        <svg xmlns='http://www.w3.org/2000/svg' height='20px' viewBox='0 -960 960 960' width='20px' fill='#008080'>
            <path
                d='m291-240-51-51 189-189-189-189 51-51 189 189 189-189 51 51-189 189 189 189-51 51-189-189-189 189Z' />
        </svg>
        clear
    </button>
</form>"

<?php
?>