// Function to navigate to a different page
function navigate(page) {
    if (page) {
        window.location.href = page;
    }
}
