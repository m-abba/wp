<?php include 'includes/header.inc'; ?>
<?php include 'includes/nav.inc' ; ?>

<main class="index-main">
    <h1>PETS VICTORIA</h1>
    <h2>
        WELCOME TO PETS
        <br>
        ADOPTION
    </h2>
    <img src="images/main.jpg" alt="Main" class="main-image">

</main>
<?php include 'includes/footer.inc'; ?>
