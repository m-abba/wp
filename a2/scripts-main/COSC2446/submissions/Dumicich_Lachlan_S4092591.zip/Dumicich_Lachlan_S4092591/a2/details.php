<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the database connection file
include 'db_connect.php';

// Get petid from query string
$petid = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($petid > 0) {
    // Fetch pet details from the database
    $sql = "SELECT * FROM pets WHERE petid = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("i", $petid);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if query returned any results
    if ($result->num_rows > 0) {
        // Output data of each row
        $row = $result->fetch_assoc();

        // Use htmlspecialchars to prevent XSS
        $name = htmlspecialchars($row['petname'] ?? '');
        $type = htmlspecialchars($row['type'] ?? '');
        $age = htmlspecialchars($row['age'] ?? '');
        $location = htmlspecialchars($row['location'] ?? '');
        $description = htmlspecialchars($row['description'] ?? '');
        $image = htmlspecialchars($row['image'] ?? 'default.jpg'); // Provide a default image if 'imagename' is not set

        // Check if the image file exists, otherwise use a default image
        $imagePath = "/wp/a2/images/" . $image;
        if (!file_exists($_SERVER['DOCUMENT_ROOT'] . $imagePath)) {
            $imagePath = "/wp/a2/images/default.jpg";
        }
    } else {
        echo "No pet found with the given ID.";
        exit;
    }
} else {
    echo "Invalid pet ID.";
    exit;
}

$conn->close();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Details</title>
    <link rel="stylesheet" href="css/styleCommon.css">
    <link rel="stylesheet" type="text/css" href="css/stylesdetails.css">
</head>
<body>
<nav>
        <div class="nav-left">
            <a href="index.php">
                <img src="images/logo.png" alt="Logo" class="Logo">
            </a>
            <select id="optionsDropdown">
                <option value="" disabled selected>Select an Option...</option>
            </select>
        </div>
        <div class="search-container">
            <input type="text" placeholder="Search...">
            <img src="images/whiteSearch.png" alt="search" class="search">
        </div>
    </nav>
    <div class="container">
        <div class="pet-image">
            <img src="<?php echo htmlspecialchars($imagePath); ?>" alt="Image of <?php echo $name; ?>">
        </div>
        <div class="pet-details">
            <div class="detail-item">
                <img src="images/paw.png" alt="Logo">
                <p><strong>Type:</strong> <?php echo $type; ?></p>
            </div>
            <div class="detail-item">
                <img src="images/clock.png" alt="Clock">
                <p><strong>Age:</strong> <?php echo $age; ?></p>
            </div>
            <div class="detail-item">
                <img src="images/location.png" alt="Location Icon">
                <p><strong>Location:</strong> <?php echo $location; ?></p>
            </div>
        </div>
        <div class="pet-names">
            <p><?php echo $name; ?></p>
        </div> 
        <div class="pet-description">     
            <p><?php echo $description; ?></p>
        </div>
    </div>
    <footer>
        <p>&copy; COPYRIGHT s4092591 Lachlan Dumicich, ALL RIGHTS RESERVED | DESIGNED FOR PETS VICTORIA</p>
    </footer>
    <script src="js/main.js"></script>
</body>
</html>