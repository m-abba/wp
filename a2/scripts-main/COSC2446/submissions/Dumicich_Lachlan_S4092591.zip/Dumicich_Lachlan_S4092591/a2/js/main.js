document.addEventListener('DOMContentLoaded', function() {
    function populateDropdown(dropdownId, options) {
        const dropdown = document.getElementById(dropdownId);
        if (!dropdown) {
            console.error(`Dropdown with id ${dropdownId} not found`);
            return;
        }

        options.forEach(option => {
            const opt = document.createElement('option');
            opt.value = option.url;
            opt.textContent = option.name;
            dropdown.appendChild(opt);
        });

        // Add event listener to navigate to the selected URL on selection
        dropdown.addEventListener('change', function() {
            console.log(`Selected value: ${dropdown.value}`);
            if (dropdown.value) {
                window.location.href = dropdown.value;
            }
        });
    }

    // Example usage: Populate the first dropdown with appropriate names and URLs
    const options1 = [
        { name: 'Add Item', url: 'add.html' },
        { name: 'Gallery', url: 'gallery.php' }, // Updated link
        { name: 'Pets', url: 'pets.html' }
    ];
    populateDropdown('optionsDropdown', options1);
});