<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pets Victoria</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/styleCommon.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Poetsen+One&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Ysabeau+SC:wght@1..1000&display=swap');
    </style>
    
</head>
<body>
    <nav>
        <div class="nav-left">
            <a href="index.html">
                <img src="images/logo.png" alt="Logo" class="Logo">
            </a>
            <select id="optionsDropdown">
                <option value="" disabled selected>Select an Option...</option>
            </select>
        </div>
        <div class="search-container">
            <input type="text" placeholder="Search...">
            <img src="images/whiteSearch.png" alt="search" class="search">
        </div>
    </nav>
    <header>
        <div class="banner">
            <div>
                <div class="pV">PETS VICTORIA</div>
                <h1>Welcome to Pet Adoption</h1>
            </div>
            <img src="images/main.jpg" alt="Puppy and Kitten">
        </div>
    </header>
    <footer>
        <p>&copy; COPYRIGHT s4092591 Lachlan Dumicich, ALL RIGHTS RESERVED | DESIGNED FOR PETS VICTORIA</p>
    </footer>
    <script src="js/main.js"></script>
</body>
</html>