<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pets Victoria</title>
    <link rel="stylesheet" href="css/styleGal.css">
    <link rel="stylesheet" href="css/styleCommon.css">
</head>
<body>
    <nav>
        <div class="nav-left">
            <a href="index.php">
                <img src="images/logo.png" alt="Logo" class="Logo">
            </a>
            <select id="optionsDropdown">
                <option value="" disabled selected>Select an Option...</option>
            </select>
        </div>
        <div class="search-container">
            <input type="text" placeholder="Search...">
            <img src="images/whiteSearch.png" alt="search" class="search">
        </div>
    </nav>
    <h2>Pets Victoria has alot to offer!</h2>
    <h3>For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption into the mainstream. Our work has helped make a difference to the Victorian rescue community and thousands of pets in need of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we all still have big, hairy work to do</h3>
    <div class="gallery">
        <?php
        include 'db_connect.php';

        $sql = "SELECT petid, petname, image, caption FROM pets LIMIT 6";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo '<a href="http://localhost/wp/a2/details.php?id=' . $row["petid"] . '">';
                echo '<div class="image-container">';
                echo '<img src="images/' . $row["image"] . '" alt="' . $row["petname"] . '">';
                echo '<div class="petname">' . $row["petname"] . '</div>';
                echo '</div>';
                echo '</a>';
            }
        } else {
            echo "0 results";
        }

        $conn->close();
        ?>
    </div>
    <footer>
        <p>&copy; COPYRIGHT s4092591 Lachlan Dumicich, ALL RIGHTS RESERVED | DESIGNED FOR PETS VICTORIA</p>
    </footer>
    <script src="js/main.js"></script>
</body>
</html>