<?php
$title = "details";

/** @var mysqli $conn */
$conn = include("includes/db_connect.inc");

include("includes/header.inc");
include("includes/nav.inc");
?>

<main>
  <h3>Pets Victoria has a lot to offer!</h3>
  <p>For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption into the
    mainstream. Out work has helped make a difference to the Victorian rescue community and thousands of pets in need
    of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we all still have big, hairy
    work to do.</p>
  <div class="gallery">
    <?php
        $sql = "SElECT petid, petname, image, caption FROM pets";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='card'>";
                echo "<img src='uploads/" . $row["image"] . "' alt='" . $row["caption"] . "'>";
                echo "<h5>" . $row["petname"] . "</h5>";
                echo "<div class='overlay'>";
                echo '<svg fill="#000" height="48px" viewBox="0 -960 960 960" width="48px" xmlns="http://www.w3.org/2000/svg"> <path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/></svg>';
                echo "<p><a href='details.php?id=" . $row["petid"] . "'>Discover more!</a></p>";
                echo "</div>";
                echo "</div>";
            }
        }
    ?>

    <!--      <div class="overlay">-->
    <!--        <svg fill="#000" height="48px" viewBox="0 -960 960 960" width="48px" xmlns="http://www.w3.org/2000/svg">-->
    <!--          <path-->
    <!--            d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/>-->
    <!--        </svg>-->
    <!--        <p>Discover more!</p>-->
    <!--      </div>-->

  </div>
</main>

<?php
include("includes/footer.inc");
?>
