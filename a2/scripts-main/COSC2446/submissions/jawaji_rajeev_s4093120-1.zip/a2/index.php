<?php
$title = "details";

/** @var mysqli $conn */
$conn = include("includes/db_connect.inc");

include("includes/header.inc");
include("includes/nav.inc");
?>

<main class="homepage">
  <div style="text-align: start; margin-bottom: auto" >
    <h1 class="permanent-marker-regular"><strong>Pets Victoria</strong></h1>
    <h2>WELCOME TO PET ADOPTION</h2>
  </div>
  <img alt="dog and cat" id="homepage-image" src="images/main.jpg">
</main>

<?php
include("includes/footer.inc");
?>
