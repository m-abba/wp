<?php
$title = "details";

/** @var mysqli $conn */
$conn = include("includes/db_connect.inc");

include("includes/header.inc");
include("includes/nav.inc");
?>

<main>
    <h3>Discover Pets Victoria</h3>
    <p>Pets Victoria is a dedicated pet adoption organization based in Victoria, Australia, focused on providing a
        safe and loving environment for pets in need. With a compassionate approach, Pets Victoria works tirelessly to
        rescue, rehabilitate, and re home dogs, cats, and other animals. Their mission is to connect these deserving
        pets
        with caring individuals and families, creating lifelong bonds. The organization offers a range of services,
        including adoption counseling, pet education, and community support programs, all aimed at promoting
        responsible pet ownership and reducing the number of homeless animals.</p>

    <div class="row">
        <img alt="2 dogs and 2 cats running together in a field" src="images/pets.jpeg">
        <table>
            <thead>
            <tr>
                <th>Pet</th>
                <th>Type</th>
                <th>Age</th>
                <th>Locations</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $sql = "SELECT petid, petname, type, age, location FROM pets";
            $result = $conn->query($sql);
            if ($result -> num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td><a href='details.php?id=" . $row["petid"]. "'>" . $row["petname"] . "</a></td>";
                    echo "<td>" . $row["type"] . "</td>";
                    echo "<td>" . $row["age"] . "</td>";
                    echo "<td>" . $row["location"] . "</td>";
                    echo "</tr>";
                }
            }
            ?>
            </tbody>
        </table>
    </div>
</main>

<?php
include("includes/footer.inc");
?>
