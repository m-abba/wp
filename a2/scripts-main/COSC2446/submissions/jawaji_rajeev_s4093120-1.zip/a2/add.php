<?php
$title = "details";

/** @var mysqli $conn */
$conn = include("includes/db_connect.inc");

include("includes/header.inc");
include("includes/nav.inc");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle Form Data
    $pet_name = $_POST["pet-name"];
    $type = $_POST["type"];
    $description = $_POST["description"];
    $image = $_FILES["image"];
    $image_caption = $_POST["image-caption"];
    $age = $_POST["age"];
    $location = $_POST["location"];

    // Handle Image Upload
    $image_name = basename($image["name"]);
    $target_dir = "uploads/";
    $target_file = $target_dir . $image_name;


    // Create the uploads directory if it doesn't exist
    if (!file_exists($target_dir)) {
        if(!mkdir($target_dir, 0777, true)){
            echo "<p>Failed to create directory</p>";
        }
    }

    if (!move_uploaded_file($image["tmp_name"], $target_file)) {
        echo "<p>Sorry, there was an error uploading your file.</p>";
    }

    // Insert the record into the database
    $sql = "INSERT INTO pets (petname, type, description, image, caption, age, location) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssis", $pet_name, $type, $description, $image_name, $image_caption, $age, $location);
    if (!$stmt->execute()) {
        echo "<p>unable to create row</p>" . $conn->error;
    }

    header("Location: details.php?id=" . $conn->insert_id);
}
?>

<main>
  <h3>Add a pet</h3>
  <h4>You can add a new pet here</h4>
  <form method="POST" action="add.php" enctype="multipart/form-data">
    <label for="pet-name">Pet Name:<span class="important">*</span></label>
    <input id="pet-name" name="pet-name" placeholder="Provide a name for the pet" type="text">
    <label for="type">Type:<span class="important">*</span></label>
    <select id="type" name="type">
      <option>--Choose An Option--</option>
      <option value="dog">Dog</option>
      <option value="cat">Cat</option>
    </select>
    <label for="description">Description: <span class="important">*</span></label>
    <textarea id="description" name="description" placeholder="Describe the pet briefly"></textarea>
    <div>
      <label for="image">Select an image: <span class="important">*</span></label>
      <input id="image" name="image" type="file">
      <span class="important" style="font-size: small"><i><strong>MAX IMAGE SIZE: 500px</strong></i></span>
    </div>
    <label for="image-caption">Image Caption:<span class="important">*</span></label>
    <input id="image-caption" name="image-caption" placeholder="describe the image in one word" type="text">
    <label for="age">Age (months):<span class="important">*</span></label>
    <input id="age" name="age" placeholder="Age of a pet in months" type="number">
    <label for="location">Location:<span class="important">*</span></label>
    <input id="location" name="location" placeholder="Location of the pet" type="text">
    <div class="action-row">
      <button type="submit">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="20px"
             fill="#FCF9EC">
          <path
            d="M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q65 0 123 19t107 53l-58 59q-38-24-81-37.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160q32 0 62-6t58-17l60 61q-41 20-86 31t-94 11Zm280-80v-120H640v-80h120v-120h80v120h120v80H840v120h-80ZM424-296 254-466l56-56 114 114 400-401 56 56-456 457Z"/>
        </svg>
        <span>submit</span>
      </button>
      <button type="reset">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="20px"
             fill="#008080">
          <path
            d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/>
        </svg>
        <span>clear</span>
      </button>
    </div>
  </form>
</main>

<?php
include("includes/footer.inc");
?>
