<?php
$title = "details";

/** @var mysqli $conn */
$conn = include("includes/db_connect.inc");

include("includes/header.inc");
include("includes/nav.inc");

$pet_id = $_GET["id"];

$sql = "SELECT petname, description, image, caption, age, location, type FROM pets WHERE petid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $pet_id);

$stmt->execute();


if($stmt->affected_rows == 0){
    echo "<h3>Sorry, no pets found</h3>";
}
else{
    $stmt->bind_result($petname, $description, $image, $caption, $age, $location, $type);
    $stmt->fetch();

    echo "<div class='column'>";

    echo "<div class='details-row'>";
    echo "<img src='uploads/$image' alt='$caption'>";
    echo "</div>";

    echo "<div class='details-row'>";
    echo '<div class="details-column">';
    echo "<svg xmlns='http://www.w3.org/2000/svg' height='4rem' viewBox='0 -960 960 960' width='24px' fill='#36454F'><path d='M480-80q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-440q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-800q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-440q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-80Zm0-360Zm112 168 56-56-128-128v-184h-80v216l152 152ZM224-866l56 56-170 170-56-56 170-170Zm512 0 170 170-56 56-170-170 56-56ZM480-160q117 0 198.5-81.5T760-440q0-117-81.5-198.5T480-720q-117 0-198.5 81.5T200-440q0 117 81.5 198.5T480-160Z'/></svg>";
    echo "<p>$age months</p>";
    echo '</div>';

    echo "<div class='details-column'>";
    echo "<svg xmlns='http://www.w3.org/2000/svg' height='4rem' viewBox='0 -960 960 960' width='24px' fill='#36454F'><path d='M180-475q-42 0-71-29t-29-71q0-42 29-71t71-29q42 0 71 29t29 71q0 42-29 71t-71 29Zm180-160q-42 0-71-29t-29-71q0-42 29-71t71-29q42 0 71 29t29 71q0 42-29 71t-71 29Zm240 0q-42 0-71-29t-29-71q0-42 29-71t71-29q42 0 71 29t29 71q0 42-29 71t-71 29Zm180 160q-42 0-71-29t-29-71q0-42 29-71t71-29q42 0 71 29t29 71q0 42-29 71t-71 29ZM266-75q-45 0-75.5-34.5T160-191q0-52 35.5-91t70.5-77q29-31 50-67.5t50-68.5q22-26 51-43t63-17q34 0 63 16t51 42q28 32 49.5 69t50.5 69q35 38 70.5 77t35.5 91q0 47-30.5 81.5T694-75q-54 0-107-9t-107-9q-54 0-107 9t-107 9Z'/></svg>";
    echo "<p>$type</p>";
    echo "</div>";

    echo "<div class='details-column'>";
    echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#008080"><path d="M480-480q33 0 56.5-23.5T560-560q0-33-23.5-56.5T480-640q-33 0-56.5 23.5T400-560q0 33 23.5 56.5T480-480Zm0 400Q319-217 239.5-334.5T160-552q0-150 96.5-239T480-880q127 0 223.5 89T800-552q0 100-79.5 217.5T480-80Z"/></svg>';
    echo "<p>$location</p>";
    echo '</div>';
    echo '</div>';

    echo "<div class='details-row'>";
    echo "<h3>$petname</h3>";
    echo "</div>";

    echo "<div class='details-row'>";
    echo "<p>$description</p>";
    echo "</div>";

    echo "</div>";
}

include("includes/footer.inc");

