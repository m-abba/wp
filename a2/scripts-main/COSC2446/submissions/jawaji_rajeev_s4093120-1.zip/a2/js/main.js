function doMenu() {
    let menu = document.getElementById("menu")
    let selectedIndex = menu.options.selectedIndex;
    location.href = menu.options[selectedIndex].value;
}
