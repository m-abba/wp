<!--php for the header.inc and nav.inc file to be in the index.php-->
<?php
//set the title of the page
$title = "Home";    //page title for the <title> tag in the header 
$footer_id = "footer1"; //id for footer
$nav_id = "nav1"; //id for nav

//include the header.inc and nav.inc files from the folder includes
include('includes/header.inc'); 
include('includes/nav.inc');
?>

<!--main content of the index.php page-->
<main>
    <div class="home_background">
        <div class="content_container1">
            <div id="main_text">
                <h1>PETS VICTORIA</h1>
                <h2>WELCOME TO PET ADOPTION</h2>
            </div>
        <img id="home_image" src="images/main.jpg" alt="Dog and Cat together image">
        </div>
    </div>
</main>

<!--php for the footer.inc file to be in the index.php-->
<?php
include('includes/footer.inc');
?>
