<!--php for the header.inc and nav.inc file to be in the pets.php-->
<?php
//set the title of the page
$title = "Discover Pets";    //page title for the <title> tag in the header 
$nav_id = "nav2"; //id for nav
$footer_id = "footer2"; //id for footer

//include the header.inc and nav.inc files from the folder includes
include('includes/header.inc'); 
include('includes/nav.inc');
?>

<!--main content of the pets.php page-->
<main> 
    <!--Main Text Area-->
    <div id="main-text">
        <h3>Discover Pets Victoria</h3>
        <p id="p-text">PETS VICTORIA IS A DEDICATED PET ADOPTION ORGANIZATION BASED IN VICTORIA, AUSTRALIA, FOCUSED ON PROVIDING A SAFE AND LOVING ENVIRONMENT FOR PETS IN NEED. WITH A COMPASSIONATE APPRAOCH, PETS VICTORIA WORKS TIRELESSLY TO RESCUE, REHABILITATE, AND REHOME DOGS, CATS, AND OTHER ANIMALS. THEIR MISSION IS TO CONNECT THESE DESERVING PETS WITH CARING INDIVIDUALS AND FAMILIES, CREATING LIFELONG BONDS. THE ORGANISATION OFFERS A RANGE OF SERVICE, INCLUDING ADOPTION COUNSELING, PET EDUCATION, AND COMMUNITY SUPPORT PROGRAMS, ALL AIMED AT PROMOTING RESPONSIBLE PET OWNERSHIP AND REDUCING THE NUMBER OF HOMELESS ANIMALS.</p>
    </div>
    <!--Container for image and pets table-->
    <div class="image-table">
        <img src="images/pets.jpeg" alt="Animals Running Together">
        <!--Table for pets-->
        <table>
            <tr>
                <th class="th-header">PET</th>
                <th class="th-header">TYPE</th>
                <th class="th-header">AGE</th>
                <th class="th-header">LOCATION</th>
            </tr>
            <!--php code to retrieve data from the database-->
            <?php
            //connect to the database, 'petsvictoria', using an external file
            include('includes/db_connect.inc');
            //define the sql query to select all records from the 'pets' table
            $sql = "select * from pets";
            //execute the query and store the result in a variable
            $result = $conn->query($sql);

            //if statement to check if query returns any rows from the database
            if($result->num_rows > 0)
            {
                //while loop used to iterate through each row in the result set
                while($row = $result->fetch_array())
                {
                    //start a new table row
                    print("<tr>\n");
                    //Contains hyperlink to the details.php passing petid as URL parameter
                    print "<td><a href='details.php?petid=" . urlencode($row['petid']) . "'>{$row['petname']}</a></td>\n";
                    //create a table cell for pet type
                    print "<td>{$row['type']}</td>\n";
                    //create a table cell for pet's age
                    print "<td>{$row['age']}</td>\n"; 
                    //create a table cell for pet's location
                    print "<td>{$row['location']}</td>\n";
                }
            }
            else
            {
                //if no pets are available in the database, display a message to the user that no pets are available
                echo "<tr><td colspan='4'>No Pets Available</td></tr>";
            }
            ?>
        </table>
    </div>
</main>

<!--php for the footer.inc file to be in the pets.php and also to close database collection-->
<?php
include('includes/footer.inc');
$conn->close();
?>


