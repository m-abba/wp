<!--details.php created to display all data for a given pet-->

<!--php for the header.inc, title and nav.inc file to be in the details.php-->
<?php
$title = "Details";    //page title for the <title> tag in the header
$footer_id = "footer2"; //id for footer
//include the header.inc and nav.inc files from the folder includes, to keep consistent page layout
include('includes/header.inc');
include('includes/nav.inc');
?>

<?php
//If statment to check if the 'petid' parameter is present in the URL and is not empty
if(!empty($_GET['petid']))
{
    //include the db_connect.inc file to connect to the database
    include('includes/db_connect.inc');
    //get the 'petid' from the URL
    $petid = $_GET['petid'];
    //prepare the SQL query to select the pet details based on the provided 'petid'
    $sql = "select * from pets where petid = ?";
    //prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    //bind the 'petid' to the SQl statement as an integer (i)
    $stmt->bind_param("i", $petid);
    //execute the prepared SQL statement
    $stmt->execute();
    //get the result of the query
    $result = $stmt->get_result();

    //if statement to check if the query returned any rows from the database, if so, display the pet details
    if($result->num_rows > 0)
    {
        //while loop used to fetch the result row by row. Safety Check.
        while($row = mysqli_fetch_array($result))
        {
            //display the pet details in a separate webpage
            //print pet image
            print "<img class='image_details' src='" . $row["image"] . "' alt='" . $row['caption'] . "'>";
            //pet's details
            print "<div class='details'>";
            //display pet's age with an alarm icon
            print "<div class='icon-container'>";
            print "<span class='material-symbols-outlined' id='alarm_icon'>alarm</span>";
            print "<p><br><br>" . $row["age"] . " MONTHS </p>";
            print "</div>";
            //display pet type with an pet icon
            print "<div class='icon-container'>";
            print "<span class='material-symbols-outlined' id='pet_icon'>PETS</span>";
            print "<p>" . $row["type"] . "</p>";
            print "</div>";
            //display pet location with a location icon
            print "<div class='icon-container'>";
            print "<span class='material-symbols-outlined' id='location_icon'>location_on</span>";
            print "<p><br><br>" . $row["location"] . "</p>";
            print "</div>";
            print "</div>";
            //display the pet's name in a heading
            print "<h3>" . $row["petname"] . "</h3>";
            //display the pet's description in a paragraph
            print "<p>" . $row["description"] . "</p>";
        }

    }

    //close the database connection
    $conn->close();
}
?>

<!--php for the footer.inc file to be in the details.php-->
<?php
include('includes/footer.inc');
?>
