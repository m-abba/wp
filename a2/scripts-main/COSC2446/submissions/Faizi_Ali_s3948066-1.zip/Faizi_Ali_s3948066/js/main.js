// JavaScript Folder
function dropdownFunction(){
    let z = document.getElementById("dropdown").value;
// Create if-else statement for changing between webpages
    if (z == "home") {
        window.location.href = "index.php";
    }
    else if (z == "pets"){
        window.location.href = "pets.php";
    }
    else if (z == "add_pet"){
        window.location.href = "add.php";
    }
    else if (z == "gallery"){
        window.location.href = "gallery.php";
    }
}