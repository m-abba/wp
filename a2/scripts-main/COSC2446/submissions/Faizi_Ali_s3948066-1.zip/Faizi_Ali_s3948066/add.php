<!--php for the header.inc and nav.inc file to be in the add.php-->
<?php
//set the title of the page
$title = "Add Pets";    //page title for the <title> tag in the header 
$footer_id = "footer3"; //id for footer
$nav_id = "nav3"; //id for nav

//include the header.inc and nav.inc files from the folder includes
include('includes/header.inc'); 
include('includes/nav.inc');
?>

<!--main content of the pets.php page-->
<main>
    <h3 id="h3">Add a pet</h3>
    <p id="p1">YOU CAN ADD A NEW PET HERE</p>

    <!--Creating a form to add a new pet via POST method-->
    <form action="addnewpet_process.php" method="POST" enctype="multipart/form-data">
        <!--pet name field-->
        <label for="petName" class="required">PET NAME:</label>
        <input id="petName" type="text" name="petName" required placeholder="Provide a name for the pet">
        <label for="type" class="required">TYPE OF PET:</label>
        <!--pet type selection field-->
        <select name="type" id="type" required>
            <option value="">---Choose an option---</option>
            <option value="dog">DOG</option>
            <option value="cat">CAT</option>
            <option value="other">OTHER</option>
        </select>
        <!--description field-->
        <label for="Description" class="required">DESCRIPTION:</label>
        <textarea name="Description" required placeholder="Provide a brief description of the pet" id="Description"></textarea>
        <!--image upload field-->
        <div class="file-input">
            <label for="file" class="required">SELECT AN IMAGE:</label>
            <input type="file" name="image" id="file" required>
        </div>
        <!--image caption field-->
        <label for="imgCaption" class="required">IMAGE CAPTION:</label>
        <input type="text" name="imgCaption" id="imgCaption" required placeholder="Describe the image">
        <!--age field-->
        <label for="age" class="required">AGE(MONTHS):</label>
        <input type="number" name="age" id="age" required placeholder="Enter the age of the pet in months" step="0.01">
        <!--location field-->
        <label for="Location" class="required">LOCATION:</label>
        <input type="text" name="Location" id="Location" required placeholder="Enter the location of the pet">
        <!--Button field-->
        <div class="button-cont">
            <!--submit button-->
            <button type="submit">
                <span class="material-symbols-outlined">add_task</span>
                SUBMIT
            </button>
            <!--reset button-->
            <button type="reset">
                <span class="material-symbols-outlined">clear</span>
                CLEAR
            </button>
        </div>
            
    </form>
</main>

<!--php for the footer.inc file to be in the pets.php-->
<?php
include('includes/footer.inc');
?>