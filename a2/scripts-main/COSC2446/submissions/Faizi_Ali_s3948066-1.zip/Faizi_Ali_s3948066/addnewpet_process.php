<!-- to make add.php dynamic-->
<?php
$title = "Form Process";    //page title for the <title> tag in the header
$footer_id = "footer2"; //id for footer
//connect to the database server
include('includes/db_connect.inc');

//retrieve form data using the POST method
$petname = $_POST['petName']; //get value from the form
$description = $_POST['Description']; //get value from the form
$image = 'images/' . $_FILES['image']['name']; //image path - uploaded file
$caption = $_POST['imgCaption']; //get value from the form
$location = $_POST['Location']; //get value from the form
$type = $_POST['type']; //get value from the form
$age = $_POST['age']; //get value from the form

//Define the SQL query with placeholders for prepared statement
$sql = "INSERT INTO pets (petname, description, image, caption, age, location, type) VALUES (?, ?, ?, ?, ?, ?, ?)";

//prepare the sql statement to prevent SQL injection
$stmt = $conn->prepare($sql);

//bind the parameters to the placeholders, where ssssdss represents the data types of the parameters in order *s=string, d=double
$stmt->bind_param("ssssdss", $petname, $description, $image, $caption, $age, $location, $type);

//execute the prepared SQL statement
$stmt->execute();

//Check if the record was successfully created, use if-else statement
if($stmt->affected_rows > 0)
{
    //if successful, move the uploaded image from temp directory to 'images/' folder
    move_uploaded_file($_FILES['image']['tmp_name'], 'images/' . $_FILES['image']['name']);
    //include header.inc and navigation.inc and footer.inc, combined with a message saying it was successful
    include('includes/header.inc');
    include('includes/nav.inc');
    //message to user
    echo "<h2>The record has been successfully created</h2>";
    include('includes/footer.inc');
}
else
{
    //ouput to user that the record was not successfully created
    echo "Failed to upload the record";
}

//close the database connection to free resources
$conn->close();
?>
