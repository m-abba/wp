<!--gallery.php-->
<?php
$title = "Gallery";   //page title for the <title> tag in the header
$footer_id = "footer4"; //id for footer
$nav_id = "nav4"; //id for nav

//include the header.inc, nav.inc and db_connect.inc files from the folder includes
include('includes/header.inc');
include('includes/nav.inc');
include('includes/db_connect.inc');
?>

<!--main content of the gallery.php page-->
<main>
    <!--main text-->
    <h3 id="h3">Pets Victoria has a lot to offer!</h3>
    <p id="p">FOR ALMOST TWO DECADES, PETS VICTORIA HAS HELPED IN CREATING TRUE SOCIAL CHANGE BY BRINGING PET ADOPTON INTO THE MAINSTREAM. OUR WORK HAS HELPED MAKE A DIFERENCE TO THE VICTORIAN RESCUE COMMUNITY AND THOUSANDS OF PETS IN NEED OF RESCUE AND REHABILITATION. BUT, UNTIL EVERY PET IS SAFE, RESPECTED, AND LOVED, WE ALL STILL HAVE BIG, HAIRY WORK TO DO.</p>

    <?php
    //SQL query to select the petid, petname, image and caption fields from the 'pets' table
    $sql = "SELECT petid, petname, image, caption FROM pets";
    //Execute the query and store the result in the $result variable
    $result = $conn->query($sql);
    //Create a container div to hold all the pet cards
    echo "<div class='gallery-container'>";
    //Use while loop to iterate through each row in the result set and print it out
    while($row = $result->fetch_array())
    {
        echo "<div class='gallery'>";
        //Link to details.php webpage and passes 'petid' to details.php as a URL parameter
        echo "<a href='details.php?petid=" . urlencode($row['petid']) . "'>";
        //Display the pet's image with a caption used as alt attribute
        echo "<img src='" . $row['image'] . "' alt='" . $row['caption'] . "'>";
        //add search icon
        echo "<i class='material-icons'>search</i>";
        //add hiddent text when hovering over an image
        echo "<span class='hidden-text'>Discover More!</span>";
        //close the anchor tag (link)
        echo "</a>";
        //display the pet's name underneath the image
        echo "<p class='petname'>" . $row['petname'] . "</p>";
        echo "</div>";
    }
    //close the container div
    echo "</div>";
    ?>

</main>

<!--php for the footer.inc file to be in the gallery.php-->
<?php
include('includes/footer.inc');
?>
