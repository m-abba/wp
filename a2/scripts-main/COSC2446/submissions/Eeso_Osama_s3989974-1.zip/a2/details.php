<?php
$title = "Pet Details";
include('includes/header.inc');
include('includes/nav.inc');
?>
<?php
if (!empty($_GET['id'])) {
    include('includes/db_connect.inc');

    $id = $_GET['id'];

    $sql = "select * from pets where petid = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("i", $id);

    $stmt->execute();

    $result = $stmt->get_result();


    if ($result->num_rows > 0) {

        while ($row = mysqli_fetch_array($result)) {
            print "<div class='details-main'>";
            print "<img class='img-d' alt='pet-image' src=' images/{$row['image']}' >";
            print "<div class='icons'>";
            print "<div class='age'>";
            print '<svg xmlns="http://www.w3.org/2000/svg" height="48px" viewBox="0 -960 960 960" width="48px" fill="#36454F"><path d="m437-306 223-223-43-43-180 180-94-94-43 43 137 137Zm42 224q-74 0-139.5-28t-114-76.5q-48.5-48.5-77-114T120-440.73q0-74.74 28.5-140Q177-646 225.5-695t114-77Q405-800 479-800t139.5 28Q684-744 733-695t77 114.27q28 65.26 28 140 0 74.73-28 140.23-28 65.5-77 114T618.5-110Q553-82 479-82Zm0-357ZM214-867l42 42L92-667l-42-42 164-158Zm530 0 164 158-42 42-164-158 42-42ZM479.04-142Q604-142 691-229.04q87-87.05 87-212Q778-566 690.96-653q-87.05-87-212-87Q354-740 267-652.96q-87 87.05-87 212Q180-316 267.04-229q87.05 87 212 87Z"/></svg>';
            print "<p>{$row['age']} months</p>";
            print "</div>";
            print "<div class= 'type'>";
            print '<svg xmlns="http://www.w3.org/2000/svg" height="48px" viewBox="0 -960 960 960" width="48px" fill="#36454F"><path d="M169.86-485Q132-485 106-511.14t-26-64Q80-613 106.14-639t64-26Q208-665 234-638.86t26 64Q260-537 233.86-511t-64 26Zm185-170Q317-655 291-681.14t-26-64Q265-783 291.14-809t64-26Q393-835 419-808.86t26 64Q445-707 418.86-681t-64 26Zm250 0Q567-655 541-681.14t-26-64Q515-783 541.14-809t64-26Q643-835 669-808.86t26 64Q695-707 668.86-681t-64 26Zm185 170Q752-485 726-511.14t-26-64Q700-613 726.14-639t64-26Q828-665 854-638.86t26 64Q880-537 853.86-511t-64 26ZM266-75q-42 0-69-31.53-27-31.52-27-74.47 0-42 25.5-74.5T250-318q22-22 41-46.5t36-50.5q29-44 65-82t88-38q52 0 88.5 38t65.5 83q17 26 35.5 50t40.5 46q29 30 54.5 62.5T790-181q0 42.95-27 74.47Q736-75 694-75q-54 0-107-9t-107-9q-54 0-107 9t-107 9Z"/></svg>';
            print "<p>{$row['type']}</p>";
            print "</div>";
            print "<div class='location'>";
            print '<svg xmlns="http://www.w3.org/2000/svg" height="48px" viewBox="0 -960 960 960" width="48px" fill="#008080"><path d="M480.09-490q28.91 0 49.41-20.59 20.5-20.59 20.5-49.5t-20.59-49.41q-20.59-20.5-49.5-20.5t-49.41 20.59q-20.5 20.59-20.5 49.5t20.59 49.41q20.59 20.5 49.5 20.5ZM480-159q133-121 196.5-219.5T740-552q0-117.79-75.29-192.9Q589.42-820 480-820t-184.71 75.1Q220-669.79 220-552q0 75 65 173.5T480-159Zm0 79Q319-217 239.5-334.5T160-552q0-150 96.5-239T480-880q127 0 223.5 89T800-552q0 100-79.5 217.5T480-80Zm0-480Z"/></svg>';
            print "<p>{$row['location']}</p>";
            print "</div>";
            print "</div>";
            
            print "\n<h3 class='h3-d'>{$row['petname']}</h3>";
            print "<p class='para-d'>{$row['description']}</p>";
            print "</div>";
        }
    }
    $conn->close();
}
?>
<?php
include('includes/footer.inc');
?>