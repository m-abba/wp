<?php
$title = 'Gallery';
include('includes/header.inc');
include('includes/nav.inc');
include("includes/db_connect.inc");
$sql = "SELECT petid, petname, image FROM pets";
?>
    <div class="gal-main">
        <!-- Main content here -->
        <h3 class="h3-gal">Pets Victoria has a lot to offer!</h3>
        <p>For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption into the
        mainstream. Our work has helped make a
        difference to the Victorian rescue community and thousands of pets in need of rescue and rehabilitation. But, until
        every pet is safe, respected, and loved, we all
        still have big. hairy work to do.</p>
        <div class="gal-flex">
            <?php
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    echo '<a href="details.php?id='.$row["petid"].'">';
                    echo '<div class="pet-card">';
                    echo '<div class="pet-image">';
                    echo '<img src="images/'.$row["image"].'" alt="'.$row["petname"].'">';
                    echo '<div class="overlay">';
                    echo '<div class="text"><span class="search-icon"><i class="fa fa-search"></i></span><br><br>Discover more!</div>';
                    echo '</div>';
                    echo '</div>';
                    echo '<div class="pet-name"><h4>'.$row["petname"].'</h4></div>';
                    echo '</div>';
                    echo '</a>';
                }
            }
            ?>
        </div>
    </div>
<?php
include('includes/footer.inc');
?>