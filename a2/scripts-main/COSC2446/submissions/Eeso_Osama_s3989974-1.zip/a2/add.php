<?php
$title = 'Add New Pet';
include('includes/header.inc');
include('includes/nav.inc');
?>
<?php
include('includes/db_connect.inc'); // Include your database connection file

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the form data
    $petName = $_POST['petname'];
    $type = $_POST['type'];
    $description = $_POST['description'];
    $imageCaption = $_POST['caption'];
    $age = $_POST['age'];
    $location = $_POST['location'];

    // Handle the file upload
    $image = $_FILES['image']['name'];
    $target = "images/" . basename($image);
    move_uploaded_file($_FILES['image']['tmp_name'], $target);

    // Prepare SQL statement to insert data
    $sql = "INSERT INTO pets (petname, description, caption, age, type, location, image) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssisss", $petName, $description, $imageCaption, $age, $type, $location, $image);

    // Execute the SQL query
    if ($stmt->execute()) {
        echo "<p class='success-message'>New pet added successfully!</p>";
    } else {
        echo "<p class='error-message'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
    $conn->close();
}
?>
        <h3 class="add-h3">Add a pet</h3>
        <p class="add-p">You can add a new pet here</p>
        <form method="post" action="add.php" enctype="multipart/form-data">

            <label for="petName">Pet Name: <span class="asterisk">*</span> </label>
            <input type="text" name="petname" id="petName" placeholder="Provide a name for the pet" required>

            <label for="petType">Type: <span class="asterisk">*</span> </label>
            <select id="petType" name="type" required>
                <option value="">--Choose an option--</option>
                <option value="cat">Cat</option>
                <option value="dog">Dog</option>
                <option value="rabbit">Rabbit</option>
                <option value="bird">Bird</option>
                <option value="fish">Fish</option>
            </select>
            <label for="description">Description <span class="asterisk">*</span></label>
            <textarea id="description" name="description" placeholder="Describe the pet briefly" required></textarea>
            <div class="image-upload">
                <label for="image">Select an image: <span class="asterisk">*</span></label>
                <input type="file" name ="image" id="image">
                <span class="image-size-info">max image size: 500px</span>
            </div>
            <label>Image Caption: <span class="asterisk">*</span></label>
            <input type="text" name="caption" id="image-caption" placeholder="describe the image in one word" required>
            
            <label for="petAge">Age (months): <span class="asterisk">*</span></label>
            <input type="number" name="age" id="petAge" placeholder="Age of a pet in months" required>

            <label for="petLocation">Location: <span class="asterisk">*</span></label>
            <input type="text" name="location" id="petLocation" placeholder="Location of the pet" required>

            <button type="submit" class="submit-button"><svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e8eaed">
                <path
                    d="M480-96q-79.38 0-149.19-30T208.5-208.5Q156-261 126-330.96t-30-149.5Q96-560 126-629.5q30-69.5 82.5-122T330.81-834q69.81-30 149.19-30 63 0 120 19t105 54l-52 52q-37-26-81-39.5T480-792q-129.67 0-220.84 91.23-91.16 91.23-91.16 221Q168-350 259.16-259q91.17 91 220.84 91 36.87 0 71.43-8Q586-184 617-199l53 53q-42 24-89.91 37Q532.17-96 480-96Zm264-72v-120H624v-72h120v-120h72v120h120v72H816v120h-72ZM425-307 264-468l52-52 110 110 387-387 51 51-439 439Z" />
            </svg> submit</button>
            <button class="clear-button"><svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#008080">
                <path d="m291-240-51-51 189-189-189-189 51-51 189 189 189-189 51 51-189 189 189 189-51 51-189-189-189 189Z" />
            </svg>clear</button>
        </form>
<?php
include('includes/footer.inc');
?>