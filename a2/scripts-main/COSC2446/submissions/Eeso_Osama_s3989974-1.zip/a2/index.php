<?php
$title = 'Home - Pets Victoria';
include('includes/header.inc');
include('includes/nav.inc');
?>

    <div class="index-main">
        <!-- Main content here -->
        <img src="images/main.jpg" alt="Main Image" class="main-image">
        <h1>Pets Victoria</h1>
        <h2 class="main-h2">WELCOME TO PET <br>ADOPTION</h2>
        
    </div>
<?php
include('includes/footer.inc');
?>