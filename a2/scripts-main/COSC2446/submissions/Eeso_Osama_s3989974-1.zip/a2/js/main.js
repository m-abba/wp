function navigate(page) {
    window.location.href = page;
}

document.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('currentYear').textContent = new Date().getFullYear();
});
