/*
SQLyog Community v13.1.9 (64 bit)
MySQL - 5.7.44 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `pets` (
	`petid` int (11) NOT NULL AUTO_INCREMENT,
	`petname` varchar (255) NOT NULL,
	`description` text NOT NULL,
	`image` varchar (255) NOT NULL,
	`caption` varchar (255) NOT NULL,
	`age` double NOT NULL,
	`location` varchar (255) NOT NULL,
	`type` varchar (255) NOT NULL,
	PRIMARY KEY (`petid`)
); 
insert into `pets` (`petid`, `petname`, `description`, `image`, `caption`, `age`, `location`, `type`) values('1','Milo','A playful and curious kitten who loves to explore. Milo is always up for an adventure and enjoys chasing toys around the house.','cat1.jpeg','Milo playing in the park','3','Melbourne CBD','Cat');
insert into `pets` (`petid`, `petname`, `description`, `image`, `caption`, `age`, `location`, `type`) values('2','Baxter','A cheerful and energetic dog who loves playing fetch and swimming. Baxter\'s friendly demeanor makes him the perfect companion for families with children.','dog1.jpeg','Baxter on the beach','5','Cape Woolamai','Dog');
insert into `pets` (`petid`, `petname`, `description`, `image`, `caption`, `age`, `location`, `type`) values('3','Luna','A quiet and shy kitten who enjoys cuddling up in warm places. Luna is still learning about the world but already loves gentle affection.','cat2.jpeg','Luna sleeping','1','Ferntree Gully','Cat');
insert into `pets` (`petid`, `petname`, `description`, `image`, `caption`, `age`, `location`, `type`) values('4','Willow','A strong and loyal dog with a love for outdoor activities. Willow thrives on long hikes and enjoys the fresh air and nature.','dog2.jpeg','Willow running in the woods','48','Marysville','Dog');
insert into `pets` (`petid`, `petname`, `description`, `image`, `caption`, `age`, `location`, `type`) values('5','Oliver','An independent and curious cat who enjoys sunbathing. Oliver loves to observe his surroundings and explore his territory.','cat4.jpeg','Oliver enjoying the sun','12','Grampians','Cat');
insert into `pets` (`petid`, `petname`, `description`, `image`, `caption`, `age`, `location`, `type`) values('6','Bella','A friendly and playful dog who loves meeting new people. Bella enjoys her time at the park, especially when she can play with other dogs.','dog3.jpeg','Bella at the park','10','Carlton','Dog');
