<?php
    include('includes/db_connect.inc');

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $petname = $_POST['petname'];
        $description = $_POST['description'];
        $image = str_replace(' ', '', $_FILES["image"]["name"]);
        $caption = $_POST['caption'];
        $age = $_POST['age'];
        $location = $_POST['location'];
        $type = $_POST['type'];

            $sql = "INSERT INTO pets (petname, description, image, caption, age, location, type) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssiss", $petname, $description, $image, $caption, $age, $location, $type);
            
            $stmt->execute();

            if($stmt->affected_rows > 0){
                //move_uploaded_file($_FILES["image"]["tmp_name"], "images/" . $image);
            } else {
                echo "Error: " . $stmt->error;
            }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ysabeau+SC&display=swap" rel="stylesheet">
    <style>
        label.required::after{
            content: "*";
            color: red;
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php include 'includes/header.inc'; ?>
        <h3 style="font-size: 20px; text-align:center; font-weight:600; font-family:Arial, Helvetica, sans-serif; color: #36454F">
            Add a pet
        </h3>
        <p style="text-align: center">
            You can add a new pet here
        </p>
        <form action="/s4094301/wp/a2/add.php" method="POST" enctype="multipart/form-data">
            <label for = "petname" class="required">Pet Name: </label>
            <input type="text" id="petname" name="petname" placeholder="Provide a name for the pet" class="input-add" required>
            <label for = "type" class="required">Type: </label>
            <select id="type" name="type" class="select-type" required>
                <option value="" disabled selected>--Choose an option--</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
            </select>
            <label for = "description" class="required">Description </label>
            <textarea id="description" name="description" placeholder="Describe the pet briefly" class="description" required></textarea>
            <label for = "image" class="required" style="display:inline-block;">Select an Image: </label>
            <input type="file" id="image" name="image" accept="image/*" required>
            <p style="color:red; font-style:italic; font-size:15px; font-weight:500; display:inline-block;">max image size: 500px</p>
            <label for = "caption" class="required">Image Caption: </label>
            <input type="text" id="caption" name="caption" placeholder="describe the image in one word" class="input-add" required>
            <label for = "age" class="required">Age (months): </label>
            <input type="text" id="age" name="age" placeholder="Age of a pet in months" class="input-add" required>
            <label for = "location" class="required">Location: </label>
            <input type="text" id="location" name="location" placeholder="Location of the pet" class="input-add" required>
            <div class = "containersubmit">
                <button class="submitbutton">
                    <img src = "https://titan.csit.rmit.edu.au/~s4094301/wp/a2/images/add_task.png" alt="submit" width = 15 height = 15>
                    Submit
                </button>
                <button class="clearbutton">
                    <img src = "https://titan.csit.rmit.edu.au/~s4094301/wp/a2/images/close.png" alt="clear" width = 15 height = 15>
                    Clear
                </button>
            </div>
        </form>
        <?php include 'includes/footer.inc'; ?>
    </div>
    <script src = "js/main.js"></script>
</body>
</html>