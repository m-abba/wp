function dropDown(){
    let dropdown = document.getElementById("dropdown");
    let optionNumber = dropdown.options.selectedIndex;
    let url = dropdown.options[optionNumber].value;
    location.href = url;
}