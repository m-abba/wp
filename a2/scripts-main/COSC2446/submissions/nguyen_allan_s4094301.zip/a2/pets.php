<?php
    include('includes/db_connect.inc');
    $sql_clear = "DELETE FROM pets";
    $sql = "SELECT petname, type, age, location, petid FROM pets";
    $result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pets</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ysabeau+SC&display=swap" rel="stylesheet">
</head>

<body>
    <div id="wrapper">
        <?php include 'includes/header.inc'; ?>
        <h3 style="font-size: 20px; text-align:center; font-weight:600; font-family:Arial, Helvetica, sans-serif; color: #36454F">
            Discover Pets Victoria
        </h3>
        <p style="text-align: center">
            Pets Victoria is a dedicated pet adoption organisation based in Victoria, Australia, focused on providing a safe and loving environment for pets in need. With a 
            compassionate approach, Pets Victoria works tirelessly to rescue, rehabilitate, and rehome dogs, cats, and other animals. Their mission is to connect these
            deserving pets with caring individuals and families, creating lifelong bonds. The organisation offers a range of services, including adoption counseling, pet
            education, and community support programs, all aimed at promoting resposible pet ownership and reducing the number of homeless animals. 
        </p>

        <div class="containerpets">
            <img src = https://titan.csit.rmit.edu.au/~s4094301/wp/a2/images/pets.jpeg alt="pets" width = 500 style="text-align: left;">
            <table style = "text-align: right;">
                <tr>
                    <th>Pet</th>
                    <th>Type</th>
                    <th>Age</th>
                    <th>Location</th>
                </tr>
                <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) 
                        {
                            $petid = $row['petid'];
                            $petname = htmlspecialchars($row['petname'], ENT_QUOTES, 'UTF-8');
                            print "<tr>
                                    <td><a href='details.php?petid={$petid}'>{$petname}</a></td>
                                    <td>{$row['type']}</td>
                                    <td>{$row['age']} months</td>
                                    <td>{$row['location']}</td>
                                </tr>
                            ";
                        }
                    } else {
                        print "<tr><td colspan='4'>N/A</td></tr>";
                    }
                ?>
            </table>
        </div>
        <br>
        <?php include 'includes/footer.inc'; ?>
    </div>
    <script src = "js/main.js"></script>
</body>



</html>