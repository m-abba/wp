<!DOCTYPE html>
<html lang="en">

<head>
    <title>Index</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ysabeau+SC&display=swap" rel="stylesheet">
</head>

<body style = "background-color: #fcf9ec ;">
    <div id="wrapper">
        <?php include 'includes/header.inc'; ?>
        <br>
        <div class = "container">
            <div class="text">
                <h1 style="font-size: 70px;"> 
                    PETS VICTORIA 
                </h1>
                <h2 style="font-size: 60px;">
                    WELCOME TO PET 
                    ADOPTION
                </h2>
                <br>
            </div>
            <img src = "https://titan.csit.rmit.edu.au/~s4094301/wp/a2/images/main.jpg" class="image-index" alt="main" height=500>
        </div>
        <br>
        <?php include 'includes/footer.inc'; ?>
    </div>
    <script src = "js/main.js"></script>
</body>

</html>