<?php
    include 'includes/db_connect.inc';

    $sql = "SELECT petname, image, petid FROM pets";
    $result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Gallery</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ysabeau+SC&display=swap" rel="stylesheet">
</head>

<body>
    <div id="wrapper">
        <?php include 'includes/header.inc';?>
        <h3 style="font-size: 20px; text-align:center; font-weight:600; font-family:Arial, Helvetica, sans-serif; color: #36454F">
            Pets Victoria has a lot to offer!
        </h3>
        <p style="text-align:center;">
            For almost two decades, Pets Victoria has helped in creating 
            true social change by bringing pet adoption into the mainstream.
            Our work has helped make a difference to the Victorian rescue
            community and thousands of pets in need of rescue and rehabilitation.
            But, until every pet is safe, respected, and loved, we all still have
            big, heavy work to do.
        </p>
        <div class="containergallery">
            <?php
            $stmt = $conn->prepare("SELECT petname, image, petid FROM pets LIMIT 3 OFFSET 0");
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="gallery">';
                    echo '<a href="details.php?petid=' . $row['petid'] . '">';
                    echo '<img src="images/' . $row['image'] . '" alt="' . $row['petname'] . '">';
                    echo '<div class="imgoverlay">';
                    echo '<div class="imgoverlay-text">';
                    echo '<img src="https://titan.csit.rmit.edu.au/~s4094301/wp/a2/images/search.png" alt="search" style=" height:50px; width:50px; top: 20px">';
                    echo '<p>Discover more!</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</a>';
                    echo '<div class="desc">' . $row['petname'] . '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No pets found in the database.</p>';
            }
            ?>
        </div>
        <div class="containergallery">
            <?php
            $stmt = $conn->prepare("SELECT petname, image, petid FROM pets LIMIT 3 OFFSET 3");
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="gallery">';
                    echo '<a href="details.php?petid=' . $row['petid'] . '">';
                    echo '<img src="images/' . $row['image'] . '" alt="' . $row['petname'] . '">';
                    echo '<div class="imgoverlay">';
                    echo '<div class="imgoverlay-text">';
                    echo '<img src="https://titan.csit.rmit.edu.au/~s4094301/wp/a2/images/search.png" alt="search" style=" height:50px; width:50px; top: 20px">';
                    echo '<p>Discover more!</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</a>';
                    echo '<div class="desc">' . $row['petname'] . '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No pets found in the database.</p>';
            }
            ?>
        </div>
        <?php include 'includes/footer.inc'; ?>
    </div>
    <script src = "js/main.js"></script>
</body>
</html>