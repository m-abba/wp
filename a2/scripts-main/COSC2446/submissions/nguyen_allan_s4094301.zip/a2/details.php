<?php
    include('includes/db_connect.inc');

    $sql = "SELECT petname, type, age, location, description, image FROM pets";
    $result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Details</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ysabeau+SC&display=swap" rel="stylesheet">
</head>

<body>
    <div id="wrapper">
        <?php include 'includes/header.inc'; ?>
        
        <?php
            if (isset($_GET['petid'])) {
            $petid = intval($_GET['petid']);
            $stmt = $conn->prepare("SELECT petname, type, age, location, description, image FROM pets WHERE petid = ?");
            $stmt->bind_param("i", $petid);
            $stmt->execute();
            $stmt->bind_result($petname, $type, $age, $location, $description, $image);
            if ($stmt->fetch()) {
                echo "<div style='text-align: center; margin-top: 50px;'><img src='images/$image' alt='$petname'></div>";

                echo "<div style='margin-top: 40px; display: flex; justify-content: center; gap: 400px; text-align: center; margin-left: 50px;'>";

                    echo "<div><img src='images/clock_icon.png' alt='Age Icon' style='display: block; margin: 0 auto; width: 40px; height: 40px;'>
                    <p>Age: $age</p>
                    </div>";
                    
                    echo "<div><img src='images/paw_icon.png' alt='Type Icon' style='display: block; margin: 0 auto; width: 40px; height: 40px;'>
                    <p>$type</p>
                    </div>";

                    echo "<div><img src='images/location_icon.png' alt='Location Icon' style='display: block; margin: 0 auto; width: 40px; height: 40px;'>
                    <p>$location</p>
                    </div>";

                echo "</div>";

                echo "<h3 style='font-size: 20px; text-align: center; font-weight: 600; font-family: Arial, Helvetica, sans-serif; color: #36454F; margin-top: 35px;'>$petname</h3>";
                echo "<p style='text-align: center; margin-bottom: 60px;'>$description</p>";
            } else {
                echo "<p>Pet not found.</p>";
            }
            $stmt->close();
            } else {
            echo "<p>No pet selected.</p>";
            }
        ?>

        <?php include 'includes/footer.inc'; ?>
    </div>
    <script src = "js/main.js"></script>
</body>

</html>