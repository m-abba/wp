<?php include 'include/header.inc'; ?>
<?php include 'include/nav.inc'; ?>
<?php include 'include/db_connect.inc'; ?>
<main>
    <?php
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM pets WHERE petid = ?");
    $stmt->execute([$id]);
    $pet = $stmt->fetch();

    if ($pet) {
        $petName_details ="<h3 class=details >{$pet['petname']}</h3>";
        $petImage_details = "<img src='images/{$pet['image']}' alt='{$pet['caption']}' style='max-width: 300px; height: auto;'>";
        $petType_details ="{$pet['type']}";
        $petAge_details = "{$pet['age']} months";
        $petLocation_details = "{$pet['location']}";
        $petDescription_details = "{$pet['description']}";
        
    } else {
        echo "Pet not found.";
    }
    ?>
    <div class="pet-Details">
        <div>
            <img src="images/<?php echo $pet['image']; ?>" alt="<?php echo $pet['caption']; ?>" class="pet-image">
        </div>
        <div class="pet-information">
            <div class="pet_Descript">
                <span class="material-symbols-outlined" id="clock-icon">alarm</span>
                <label><?php echo $petAge_details;?></label>
            </div>
            <div class="pet_Descript">
                <span class="material-symbols-outlined" id="paw-icon">pets</span>
                <label><?php echo $petType_details;?></label>
            </div>
            <div class="pet_Descript">
                <span class="material-symbols-outlined" id="location-icon">location_on</span>
                <label><?php echo $petLocation_details;?></label>
            </div>
        </div>

        <?php echo $petName_details; ?>
        <p class="about_the_Pet"><?php echo $petDescription_details; ?></p>
    </div>


</main>
<?php include 'include/footer.inc'; ?>