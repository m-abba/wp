function navigate() {
    var dropdown = document.getElementById("menu");
    var selectedValue = dropdown.value;

    if (selectedValue) {
        window.location.href = selectedValue;
    }

    // Reset dropdown to "Select Option..." after navigating
    dropdown.selectedIndex = 0;
}

// Function to update the dropdown based on the current URL
function setDropdownToCurrentPage() {
    var dropdown = document.getElementById("menu");
    var currentPage = window.location.pathname.split("/").pop();

    for (var i = 0; i < dropdown.options.length; i++) {
        if (dropdown.options[i].value === currentPage) {
            dropdown.selectedIndex = i;
            break;
        }
    }
}

// Call the function when the page loads
window.onload = function () {
    setDropdownToCurrentPage();

    // Reset dropdown to "Select Option..." after page load
    document.getElementById("menu").selectedIndex = 0;
};

