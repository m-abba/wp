<?php
include 'include/db_connect.inc';  // Connect to the database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture form data
    $petname = $_POST['petname'];
    $type = $_POST['type'];
    $description = $_POST['description'];
    $age = $_POST['age'];
    $location = $_POST['location'];
    $caption = $_POST['caption'];
    
    // Handle file upload
    $image = $_FILES['image']['name'];
    $target_dir = "images/";
    $target_file = $target_dir . basename($image);

    // Move uploaded file to the images directory
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        // Insert the pet information into the database
        $stmt = $pdo->prepare("INSERT INTO pets (petname, type, description, age, location, caption, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$petname, $type, $description, $age, $location, $caption, $image]);
        echo "Pet added successfully!";
        header ("Location: pets.php");
    } else {
        echo "Error uploading image.";
    }
}
?>
