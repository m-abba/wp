<?php
    include 'include/header.inc';
    include 'include/nav.inc';
?>

    <main>
        <div class="welcome">
            <div class="content">
                <h1>PETS VICTORIA</h1>
                <h2>WELCOME TO PET</h2>
                <h3>ADOPTION</h3>
            </div>

            <div class="contentimg">
                <img src="images/main.jpg" alt="Puppy and Kitten">
            </div>
        </div>


    </main>

<?php
include 'include/footer.inc';
?>