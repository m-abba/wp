<?php
    include 'include/header.inc';
    include 'include/nav.inc';
?>

<main>
    <section class="formSection">
        <h1 class="addFormTitle">Add a pet</h1>
        <p class="TitleUndertext">You can add a new pet here</p>
        <form class="petForm" action="sql.php" method="POST" enctype="multipart/form-data">
            <label for="pet-name">Pet Name: <span class="required">*</span></label>
            <input type="text" id="pet-name" name="petname" placeholder="Provide a name for the pet" required>

            <label for="pet-type">Type: <span class="required">*</span></label>
            <select id="pet-type" name="type" required>
                <option value="">--Choose an option--</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
                <option value="other">Other</option>
            </select>

            <label for="description">Description: <span class="required">*</span></label>
            <textarea id="description" name="description" placeholder="Describe the pet briefly" required></textarea>

            <label for="pet-image">Select an Image: <span class="required">*</span></label>
            <input type="file" id="pet-image" name="image" accept="image/*" required>
            <span class="imageSize">Max image size: 500px</span>

            <label for="image-caption">Image Caption: <span class="required">*</span></label>
            <input type="text" id="image-caption" name="caption" placeholder="Describe the image in one word" required>

            <label for="age">Age (months): <span class="required">*</span></label>
            <input type="number" id="age" name="age" placeholder="Age of a pet in months" required>

            <label for="location">Location: <span class="required">*</span></label>
            <input type="text" id="location" name="location" placeholder="Location of the pet" required>

            <div class="form-actions">
                <button type="submit" class="submitButton">Submit</button>
                <button type="reset" class="resetButton">Clear</button>
            </div>
        </form>
    </section>
</main>

<?php
    include 'include/footer.inc';
?>
