<?php
    include 'include/header.inc';
    include 'include/nav.inc';
    include 'include/db_connect.inc';
?>

    <main>
    <div class="petsMain">
        <h2>
            Discover Pets Victoria
        </h2>
        <p>
            PETS VICTORIA IS A DEDICATED PET ADOPTION
            ORGANIZATION BASED IN VICTORIA, AUSTRALIA,
            FOCUSED ON PROVIDING A SAFE AND LOVING
            ENVIRONMENT FOR PETS IN NEED. WITH A
            COMPASSIONATE APPROACH, PETS VICTORIA
            WORKS TIRELESSLY TO RESCUE, REHABILITATE,
            AND REHOME DOGS, CATS, AND OTHER ANIMALS.
            THEIR MISSION IS TO CONNECT THESE DESERVING
            PETS WITH CARING INDIVIDUALS AND FAMILIES,
            CREATING LIFELONG BONDS. THE ORGANIZATION
            OFFERS A RANGE OF SERVICES, INCLUDING
            ADOPTION COUNSELING, PET EDUCATION, AND
            COMMUNITY SUPPORT PROGRAMS, ALL AIMED AT
            PROMOTING RESPONSIBLE PET OWNERSHIP AND
            REDUCING THE NUMBER OF HOMELESS ANIMALS.
        </p>
        <img src="images/pets.jpeg" alt="Dogs running">
        <div class="table">
            <table class="petInfo">
            <tr>
                    <th>Pet</th>
                    <th>Type</th>
                    <th>Age</th>
                    <th>Location</th>
                </tr>
            <?php
        $stmt = $pdo->query("SELECT petid, petname, type, age, location FROM pets");
        while ($row = $stmt->fetch()) {
            echo "<tr>";
            echo "<td><a href='details.php?id={$row['petid']}'>{$row['petname']}</a></td>";
            echo "<td>{$row['type']}</td>";
            echo "<td>{$row['age']} months</td>";
            echo "<td>{$row['location']}</td>";
            echo "</tr>";
        }
        ?>
            </table>
        </div>
    </div>
</main>
<?php include 'include/footer.inc';?>



