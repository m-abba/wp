<?php
    include 'include/header.inc';  // Include header file
    include 'include/nav.inc';     // Include navigation file
    include 'include/db_connect.inc'; // Database connection
?>

<main>
    <h2 class="title">Pets Victoria has a lot to offer!</h2>
            <p class="description">
                For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption
                into the mainstream. Our work has helped make a difference to the Victorian rescue community and
                thousands of pets in need of rescue and rehabilitation. But, until every pet is safe, respected, and
                loved, we all still have big, hairy work to do.
            </p>
            <div class="container">
        <?php
        // Fetch all pet images from the database
        $stmt = $pdo->query("SELECT petid, image, caption FROM pets");
        
        while ($row = $stmt->fetch()) {
            // Display each image with a link to the details page in a square format
            echo "<div class='petPic'>";
            echo "<a href='details.php?id={$row['petid']}'>";
            echo "<img src='images/{$row['image']}' alt='{$row['caption']}' class='gallery-image' style='object-fit: fill; width: 100%; height: 90%;'>";
            echo "<div class='overlay'><p>Discover more!</p></div>";
            echo "</a>";
            echo "{$row['caption']}";  // Displays image caption
            echo "</div>";
        }
        ?>
    </div>
</main>

<?php
    include 'include/footer.inc';  // Includes footer file
?>