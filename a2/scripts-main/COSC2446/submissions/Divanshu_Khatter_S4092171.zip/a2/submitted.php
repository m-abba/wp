<?php include('include/header.inc'); ?>
<?php include('include/nav.inc'); ?>
<?php include('include/db_connect.inc'); ?>

<main>

</main>

<?php include('include/footer.inc'); ?>