<?php
    include("includes/header.inc");
    include("includes/nav.inc")
?>
    <div class="home-main">
        <img src="images/main.jpg" id="main-image" alt="Welcome to Pet Adoption">
        <h1>PETS VICTORIA</h1>
        <h2>WELCOME TO PET ADOPTION</h2>
    </div>
<?php
    include("includes/footer.inc")
?>