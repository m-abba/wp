<?php
    include("includes/header.inc");
    include("includes/nav.inc")
?>

    <h3>Pets Victoria has a lot to offer!</h3>
    <p>For almost two decades, Pets Victoria has helped in creating the social change by bringing pet adoption into the mainstream. Our work has helped make a difference to the Victorian rescue community and thousands of pets in need of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we all still have big, hairy work to do.</p>

    <div class='gallery-main'>
    <?php
        include("includes/db_connect.inc");

        $pets = $conn->query("select * from pets");
        if ($pets->num_rows > 0) {        
            while ($row = $pets->fetch_array()) {
                echo 
                "<div class='gallery-image'>  
                    <div class='gallery-hidden'>      
                        <span class='material-symbols-outlined'>
                            search
                        </span>
                        <a href='details.php?id=".urlencode($row['petid'])."'><p>Discover more</p></a>
                    </div>
                    <img src='images/{$row['image']}' alt='{$row['caption']}'>
                    <h3>{$row['petname']}</h3>
                </div>";
            }
        }
    ?>
    </div>
<?php
    include("includes/footer.inc")
?>