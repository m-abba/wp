<?php
    //table pets

include("includes/db_connect.inc");

foreach ($_POST as $index => $value) {
    $$index = trim($value);
}

$sql = "INSERT INTO pets (petname, description, image, caption, age, location, type) VALUES (?,?,?,?,?,?,?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssdss", $petname, $description, $_FILES['image']['name'], $caption, $age, $location, $type);

$stmt->execute();
$conn->close();
if ($stmt->affected_rows > 0) {
    if (!empty($_FILES['image'])) {
        $tmp = $_FILES['image']['tmp_name'];
        $dest = 'images/'.$_FILES['image']['name'];
        move_uploaded_file($tmp, $dest);

        header("Location:pets.php");
        exit(0);
    } else {
        echo "No image could be found!";
    }
} else {
    echo "An error has occured!";
}