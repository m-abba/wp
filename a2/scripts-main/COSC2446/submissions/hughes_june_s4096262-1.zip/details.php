<?php
    include("includes/header.inc");
    include("includes/nav.inc");

if (!empty($_GET['id'])) {
    include("includes/db_connect.inc");

    $petid = $_GET['id'];
    $sql = "select * from pets where petid = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $petid);

    $stmt->execute();
    $pet = $stmt->get_result();
    if ($pet->num_rows > 0) {  
        while ($row = $pet->fetch_array()) {
            echo "<br><img class='detail-image' src='images/".$row['image']."' alt='{$row['caption']}'><br>";
            echo 
            "<div class='details'>
                <div class='detail-icon'>
                    <div class='detail-content'>
                        <span class='material-symbols-outlined'>
                            alarm
                        </span><br>
                        <p>{$row['age']} months</p>
                    </div>
                </div>
                <div class='center-detail'>
                    <div class='detail-content'>
                        <span class='material-symbols-outlined'>
                            pets
                        </span><br>
                        <p>{$row['type']}</p>
                    </div>
                </div>
                <div class='detail-icon'>
                    <div class='detail-content'>
                        <span class='material-symbols-outlined'>
                            location_on
                        </span><br>
                        <p>{$row['location']}</p>
                    </div>
                </div>
            </div>";

            echo "<h3>{$row['petname']}</h3>
            <p>{$row['description']}</p>";
        }
    } else {
        echo "<h1>Could not find pet!</h1>";
    }
}

    include("includes/footer.inc")
?>