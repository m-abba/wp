function navigationScript() {
    let thing = document.getElementById("navigation-dropdown").value;
    location.href = thing
}