<?php
    include("includes/header.inc");
    include("includes/nav.inc")
?>
    
    <div class="addMain">
        <h3>Add a pet</h3>
        <p>You can add a new pet here</p>

        <form action="process_add.php" method="post" enctype="multipart/form-data">
            <label for="petname">Pet name: </label><br>
            <input type="text" name="petname" id="petname" required><br>
            <label for="type">Type: </label><br>
            <select name="type" id="type" required>
                <option value="" selected disabled hidden>--Select an option--</option>
                <option>Cat</option>
                <option>Dog</option>
                <option>Rabbit</option>
                <option>Other</option>
            </select><br>
            <label for="description">Description: </label><br>
            <input type="text" name="description" id="description" required><br>
            <label for="image">Select an image: </label>
            <input type="file" name="image" id="image" required><br>
            <label for="caption">Image caption: </label><br>
            <input type="text" name="caption" id="caption" required><br>
            <label for="age">Age (months): </label><br>
            <input type="text" name="age" id="age" required><br>
            <label for="location">Location: </label><br>
            <input type="text" name="location" id="location" required><br>

            <div class="form-end">
                <input type="submit"> <input type="reset">
            </div>
        </form>
    </div>
<?php
    include("includes/footer.inc")
?>