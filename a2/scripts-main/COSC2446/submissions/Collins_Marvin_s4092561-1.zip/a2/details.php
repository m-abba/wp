<?php
$title = "Details";
include('includes/header.inc');
include('includes/nav.inc');

if (!empty($_GET['petid'])) {
    include('includes/db_connect.inc');
    $petid = $_GET['petid'];
    
    $sql = "SELECT * FROM pets WHERE petid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $petid);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $imagePath = 'images/' . htmlspecialchars($row["image"]);
            echo "<div class='pet-details-container'>";
            echo "<img class='pet-image' src='$imagePath' alt='" . htmlspecialchars($row['caption']) . "'>";
            echo "<div class='icon-row'>";
            echo "<div>";
            echo "<span class='material-symbols-outlined'>schedule</span>";
            echo "<span class='icon-text'>" . htmlspecialchars($row["age"]) . " Months</span>";
            echo "</div>";
            echo "<div>";
            echo "<span class='material-symbols-outlined'>pets</span>";
            echo "<span class='icon-text'>" . htmlspecialchars($row["type"]) . "</span>";
            echo "</div>";
            echo "<div>";
            echo "<span class='material-symbols-outlined'>location_on</span>";
            echo "<span class='icon-text'>" . htmlspecialchars($row["location"]) . "</span>";
            echo "</div>";
            echo "</div>";
            echo "<h3 class='pet-name'>" . htmlspecialchars($row["petname"]) . "</h3>";
            echo "<p class='pet-description'>" . htmlspecialchars($row["description"]) . "</p>";
            echo "</div>";
        }
    } else {
        echo "No records found.";
    }

    $stmt->close();
    $conn->close();
}
?>

<?php include('includes/footer.inc'); ?>
