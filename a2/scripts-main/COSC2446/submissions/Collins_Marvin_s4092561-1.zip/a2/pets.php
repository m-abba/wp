<?php
$title = "pets";
include('includes/header.inc');
include('includes/nav.inc');
include('includes/db_connect.inc');

$query = "SELECT petid, petname, type, age, location, image, caption FROM pets";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}
?>
<body id="Pets_page">
    <main id="pets">
        <h1 class="toptitle">Discover Pets Victoria</h1>
        <p>Pets Victoria is a dedicated pet adoption agency based in Victoria, Australia, focused on providing a safe
            and loving environment for pets in need. With a compassionate approach, Pets Victoria works tirelessly to
            rescue, rehabilitate, and rehome dogs, cats, and other animals. Their mission is to connect these deserving
            pets with caring individuals and families, creating lifelong bonds. The organisation offers a range of
            services, including adoption counseling, pet education, and community support programs, all aimed at
            promoting responsible pet ownership and reducing the number of homeless animals.</p>
        <img src="images/pets.jpeg" alt="pets">
        <table>
            <tr id="tableheader">
                <th>Pets</th>
                <th>Type</th>
                <th>Age</th>
                <th>Location</th>
            </tr>
            <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo '<td><a href="details.php?petid=' . htmlspecialchars($row['petid']) . '">' . htmlspecialchars($row['petname']) . '</a></td>';
                    echo "<td>" . htmlspecialchars($row['type']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['age']) . " months</td>";
                    echo "<td>" . htmlspecialchars($row['location']) . "</td>";
                    echo "</tr>";
                }
                mysqli_free_result($result);
            ?>
        </table>
    </main>
    <?php include('includes/footer.inc'); ?>
<?php
mysqli_close($conn);
?>
