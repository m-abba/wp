<?php
$title = "Add a Pet";
include('includes/header.inc');
include('includes/nav.inc');
include('includes/db_connect.inc');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $petName = $_POST['petname'];
    $type = $_POST['type'];
    $description = $_POST['description'];
    $caption = $_POST['caption'];
    $age = $_POST['age'];
    $location = $_POST['location'];

    $targetDir = "images/";
    $targetFile = $targetDir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check === false) {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    if ($_FILES["image"]["size"] > 2000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    $allowedFormats = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($imageFileType, $allowedFormats)) {
        echo "Sorry, only JPG, JPEG, PNG, & GIF files are allowed.";
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded due to errors.";
    } else {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $imageFilename = htmlspecialchars(basename($_FILES["image"]["name"]));
            $stmt = $conn->prepare("INSERT INTO pets (petname, description, image, caption, age, location, type) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssdss", $petName, $description, $imageFilename, $caption, $age, $location, $type);

            if ($stmt->execute()) {
                echo "New pet added successfully.";
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Sorry, there was an error uploading your file. Error Code: " . $_FILES["image"]["error"];
        }
    }
}
?>

<body id="add">
    <main>
        <div class="form">
            <h1 id="ah1">Add a Pet</h1>
            <h2 id="ah2">You can add a new pet here</h2>
            <form method="post" enctype="multipart/form-data">
                <label class="required" for="pname">Pet Name:</label>
                <input type="text" id="pname" name="petname" placeholder="Provide a name for the pet" required>
                
                <label class="required" for="type">Type:</label>
                <select name="type" id="type" required>
                    <option value="" disabled selected>--Choose an option--</option>
                    <option value="Cat">Cat</option>
                    <option value="Dog">Dog</option>
                    <option value="Rodent">Rodent</option>
                    <option value="Bird">Bird</option>
                </select>

                <label class="required" for="description">Description:</label>
                <textarea name="description" id="description" placeholder="Describe the pet briefly" required></textarea>
                
                <label class="required" for="file-input">Select an Image:</label>
                <input type="file" id="file-input" name="image" accept="image/*" required>

                <label class="required" for="ID">Caption for Image:</label>
                <input type="text" id="ID" name="caption" placeholder="Describe the image in one word" required>
                
                <label class="required" for="age">Age (Months):</label>
                <input type="number" id="age" name="age" placeholder="Age of pets in months" required>
                
                <label class="required" for="Location">Location:</label>
                <input type="text" id="Location" name="location" placeholder="Location of the pet" required>
                
                <div class="button-container">
                    <button class="button" id="submit" type="submit">
                        <span class="material-symbols-outlined">add_task</span>
                        Submit
                    </button>
                    <button class="button" id="clear" type="reset">
                        <span class="material-symbols-outlined">close</span>
                        Clear
                    </button>
                </div>
            </form>
        </div>
    </main>
</body>
<?php include('includes/footer.inc'); ?>
