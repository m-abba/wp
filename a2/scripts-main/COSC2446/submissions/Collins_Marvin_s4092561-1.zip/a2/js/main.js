function dropDown() {
    let x = document.getElementById("dropmenu");
    let menu = x.value;
    
    if (menu == "home"){
        window.location.href ="index.php";
    } else if (menu == "pets") {
        window.location.href="pets.php";
    } else if (menu == "add") {
        window.location.href="add.php"
    } else if (menu == "gallery") {
        window.location.href="gallery.php"
    }
}