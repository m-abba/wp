<?php
    $title = "home";
    include('includes/header.inc');
    include('includes/nav.inc');
    include('includes/db_connect.inc');
?>
<body id="home_page">
    <main id="index">
            <h1>PETS VICTORIA</h1>
            <h2>WELCOME TO PET <br>ADOPTION</h2>
            <img src="images/main.jpg" alt="main">
        </main>
<?php include('includes/footer.inc'); ?>
