<?php
$title = "Gallery";
include('includes/db_connect.inc');
include('includes/header.inc');
include('includes/nav.inc');
?>
<body id="add">
    <main id="gallery">
        <h3>Pets Victoria has a lot to offer!</h3>
        <p id="top">For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption
      into the mainstream. Our work has helped make a difference to the Victorian rescue community and thousands of pets
      in need of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we all still have big,
      hairy work to do.</p>

        <div class="gallery-wrapper">
            <div class="gallery">
                <?php
                $query = "SELECT petid, petname, image FROM pets";
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="gallery-item">';
                        echo '<div class="image-container">';
                        echo '<a href="details.php?petid=' . htmlspecialchars($row['petid']) . '">';
                        $imagePath = 'images/' . htmlspecialchars($row['image']);
                        echo '<img src="' . $imagePath . '" alt="' . htmlspecialchars($row['petname']) . '">';
                        echo '<div class="overlay">';
                        echo '<span class="material-symbols-outlined gallery-symbol">search</span>';
                        echo '<p>Discover more!</p>';
                        echo '</div>';
                        echo '</a>';
                        echo '</div>';
                        echo '<p class="pet-name">' . htmlspecialchars($row['petname']) . '</p>';
                        echo '</div>';
                    }
                } else {
                    echo "<p>No pets available in the gallery.</p>";
                }
                ?>
            </div>
        </div>
    </main>
    <?php include('includes/footer.inc'); ?>
</body>
