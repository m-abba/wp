
<?php
$title = "Add a pet";
include("includes/header.inc");

include("includes/nav.inc");
?>
    <main>
    <h3>Add a pet</h3>
    <p>
        You can add a new pet here
    </p>

    <form action="add.php" method="post" enctype="multipart/form-data">
        <label>Pet Name:<span class="required"> *</span></label><br>
        <input type="text" class="text-input" name="petname" placeholder="Provide a name for the pet" required><br>

        <label for="pet-type">Type:<span class="required"> *</span></label><br>
        <select id="pet-type" name="type" required>
            <option value="">--Choose an option--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option>
            <option value="other">Other</option>
        </select><br>

        <label>Description<span class="required"> *</span></label><br>
        <input type="text" class="text-input" name="description" placeholder="Describe the pet briefly" required><br>

        <label>Select an Image:<span class="required"> *</span></label>
        <input type="file" id="form-image" name="image" required><span class="required"><i>max image size: 500px</i></span><br>

        <label>Image Caption:<span class="required"> *</span></label><br>
        <textarea class="text-input" name="caption" placeholder="Describe the pet briefly"></textarea><br>

        <label>Age (months):<span class="required"> *</span></label><br>
        <input type="number" class="text-input" name="age" placeholder="Age of a pet in months" required><br>

        <label>Location:<span class="required"> *</span></label><br>
        <input type="text" class="text-input" name="location" placeholder="Location of the pet" required><br>

        <div class="form-buttons">
            <button type="submit" id="form-submit">
                <span class="material-symbols-outlined" id="submit-icon">add_task</span>
                Submit
            </button>
            <button type="reset" id="form-clear">
                <span class="material-symbols-outlined" id="clear-icon">close</span>
                Clear
            </button>
        </div>
    </form>
    </main>
<?php
function validate_input($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    foreach ($_POST as $key => $value) {
        $$key = validate_input($value);
    }

    if (isset($_FILES['image'])) {
        $image = $_FILES['image']['name'];
        $temp = $_FILES['image']['tmp_name'];
        $error = $_FILES['image']['error'];
    } else {
        $image = '';
        $temp = '';
        $error = '';
    }

    include("includes/db_connect.inc");

    $sql = "INSERT INTO pets (petname, description, image, caption, age, location, type) VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        exit("Database error.");
    }

    $stmt->bind_param("ssssiss", $petname, $description, $image, $caption, $age, $location, $type);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        move_uploaded_file($temp, "images/$image");
        echo "Record added successfully";
    } else {
        echo "Record not added";
    }
}

include("includes/footer.inc");
?>
