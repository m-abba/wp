
<?php
$title = "Pets Victoria";
include("includes/header.inc");
include("includes/db_connect.inc");
include("includes/nav.inc");
?>
    <main id="index-background">
        <div id="main-text">
            <h1>PETS VICTORIA</h1>
            <h2>WELCOME TO PET <br> ADOPTION</h2>
        </div>
        <img src="images/main.jpg" alt="Puppy and Kitten" id="main-image">
    </main>
<?php
include("includes/footer.inc");
?>
