<?php
$title = "Pet Details";
include("includes/header.inc");
include("includes/nav.inc");
include("includes/db_connect.inc");
echo "<main>"; 

if(!empty($_GET['petid'])) {
    $id = $_GET['petid'];
    $sql = "SELECT * FROM pets WHERE petid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        print "<img src='images/$row[image]' alt='Pet' id='details-image'>";

        print "<div class='details-row'>";
            print "<div class='details'>";
                $age = $row['age'];
                print "<span class='material-symbols-outlined' id='clock-icon'>alarm</span>";
                if ($age > 12) {
                    $age_in_years = round($age / 12, 1);
                    print "<p> $age_in_years years </p>";
                } else {
                    print "<p> $age months </p>";
                }
            print "</div>";
            print "<div class='details'>";
                print "<span class='material-symbols-outlined' id='paw-icon'>pets</span>";
                print "<p> $row[type] </p>";
            print "</div>";
            print "<div class='details'>";
                print "<span class='material-symbols-outlined' id='location-icon'>location_on</span>";
                print "<p> $row[location] </p>";
            print "</div>";
        print "</div>";

        print "<div id='details-text'>";
        print "<h3> $row[petname] </h3>";
        print "<p> $row[description] </p>";
        print "</div>";
    } else {
        print "<p>No pet found with the given ID.</p>";
    }
}
echo "</main>";
include("includes/footer.inc");
?>