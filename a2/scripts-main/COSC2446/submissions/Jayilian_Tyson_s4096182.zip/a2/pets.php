
<?php
$title = "Discover Pets Victoria";
include("includes/header.inc");

include("includes/nav.inc");
?>
    <main>
        <h3>Discover Pets Victoria</h3>
        <p>
            Pets Victoria is a dedicated pet adoption organization based in Victoria, Australia, focused on providing a safe and loving environment for pets in need. With a 
            compassionate approach, Pets Victoria works tirelessly to rescue, rehabilitate, and rehome dogs, cats, and other animals. Their mission is to connect these deserving pets 
            with caring individuals and families, creating lifelong bonds. The organization offers a range of services, including adoption counseling, pet education, and community 
            support programs, all aimed at promoting responsible pet ownership and reducing the number of homeless animals.
        </p>
        
        <img src="images/pets.jpeg" alt="Pets" id="pets-image">
       
        <table>
            <thead><tr>
                <th>Pet</th>
                <th>Type</th>
                <th>Age</th>
                <th>Location</th>
            </tr></thead>
            <tbody>
            <?php
            include("includes/db_connect.inc");

            $sql = "SELECT * FROM pets";
            $result = $conn -> query($sql);

            if ($result -> num_rows > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    print "<tr>";
                    print "<td><a href='details.php?petid={$row['petid']}'> $row[petname] </a></td>";
                    print "<td> $row[type] </td>";
                    $age = $row['age'];
                    if ($age > 12) {
                        $age_in_years = round($age / 12, 1);
                        print "<td> $age_in_years years </td>";
                    } else {
                        print "<td> $age months </td>";
                    }
                    print "<td> $row[location] </td>";
                    print "</tr>";
                }
            } else {
                echo " <tr><td> 0 results </td></tr>";
            }
            ?>
            </tbody>
        </table>
    </main>
<?php
include("includes/footer.inc");
?>
