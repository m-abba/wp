<?php
$title = "Pets Gallery";
include("includes/header.inc");

include("includes/nav.inc");
?>
    <main>
        <h3>Pets Victoria has a lot to offer!</h3>
        <p>
            For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption into the mainstream. Our work has helped make a 
            difference to the Victorian rescue community and thousands of pets in need of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we all 
            still have big, hairy work to do.
        </p>
        <div class="gallery-grid">
        <?php
            include("includes/db_connect.inc");

            $sql = "SELECT * FROM pets";
            $result = $conn -> query($sql);

            if ($result -> num_rows > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    print "<a href='details.php?petid={$row['petid']}'><div class='boxes'>";
                        print "<div class='image-container'>";
                            print "<img src='images/$row[image]' alt='Pet'>";
                            print "<div class='overlay'>";
                                print "<span class='material-symbols-outlined'>search</span>";
                                print "<u>Discover more!</u>";
                            print "</div>";
                        print "</div>";
                        print "<div class='pet-name'> $row[petname] </div>";
                    print "</div></a>";
                }
            } else {
                print "<p>0 results</p>";
            }
        ?>
        </div>
    </main>
<?php
include("includes/footer.inc");
?>
