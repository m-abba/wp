<?php
include('includes/db_connect.inc'); // Include the database connection
include('includes/header.inc');     // Include the header section
include('includes/nav.inc');        // Include the navigation
?>

<main class="content-container gallery-page">
    <h2 class="page-title">Pets Victoria has a lot to offer!</h2>
    <p class="intro-text">For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption into the mainstream. Our work has helped make a difference to the Victorian rescue community and thousands of pets in need of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we all still have big, hairy work to do.</p>

    <div class="gallery-grid">
        <?php
        $sql = "SELECT petid, petname, image, caption FROM pets";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each pet
            while ($row = $result->fetch_assoc()) {
                $petid = $row['petid'];
                $name = $row['petname'];
                $image = $row['image'];
                $caption = $row['caption'];

                // Display each pet's gallery item dynamically
                echo '
                <div class="gallery-item">
                    <a href="details.php?id=' . $petid . '">
                        <img src="images/' . $image . '" alt="' . $name . '" class="gallery-image">
                        <div class="gallery-caption">
                            <h3>' . $name . '</h3>
                            <p>' . $caption . '</p>
                        </div>
                    </a>
                </div>
                ';
            }
        } else {
            echo "<p>No pets found!</p>";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</main>

<?php
include('includes/footer.inc');  // Include the footer section
?>
