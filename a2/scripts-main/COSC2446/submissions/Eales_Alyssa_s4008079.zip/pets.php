<?php
include('includes/db_connect.inc'); // Include the database connection
include('includes/header.inc');     // Include the header section
include('includes/nav.inc');        // Include the navigation
?>

<main class="content-container pets-page">
    <h2 class="page-title">Discover Pets Victoria</h2>
    <p class="intro-text">Pets Victoria is a dedicated pet adoption organization focused on providing a safe and loving environment for pets in need.</p>
    
    <div class="content">
        <table class="pets-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Age (Months)</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT petid, petname, type, age, location FROM pets";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each pet
                    while ($row = $result->fetch_assoc()) {
                        $petid = $row['petid'];        
                        $name = $row['petname'];           
                        $type = $row['type'];           
                        $age = $row['age'];            
                        $location = $row['location'];   

                        echo '
                        <tr>
                            <td><a href="details.php?id=' . $petid . '">' . $name . '</a></td>
                            <td>' . $type . '</td>
                            <td>' . $age . '</td>
                            <td>' . $location . '</td>
                        </tr>';
                    }
                } else {
                    echo "<tr><td colspan='4'>No pets found!</td></tr>";
                }

                // Close the database connection
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</main>

<?php
include('includes/footer.inc');  // Include the footer section
?>
