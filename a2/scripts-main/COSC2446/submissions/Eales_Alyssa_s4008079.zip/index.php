<?php
    include ("includes/db_connect.inc");
    include ("includes/header.inc");
    include ("includes/nav.inc");
?>
<div class="wrapper">
    <main class="content-container index-page">
        <h1 class="site-title">Pets Victoria</h1>
        <h2 class="site-subtitle">Welcome to Pet Adoption</h2>
        <div class="content">
            <p>This website is dedicated to connecting loving homes with pets in need of adoption. Take a look at the available pets or learn how you can help today!</p>
            <img src="images/main.jpg" alt="Dog and Cat" class="main-image">
        </div>
    </main>
</div>
<?php
    include ("includes/footer.inc");
?>
