<?php
include('includes/db_connect.inc'); // Include the database connection
include('includes/header.inc');     // Include the header section
include('includes/nav.inc');        // Include the navigation
?>

<main class="content-container add-page">
    <h2 class="page-title">Add a pet</h2>
    <p class="intro-text">You can add a new pet here</p>

    <form class="add-pet-form" action="add.php" method="POST" enctype="multipart/form-data">
        <label for="petname">Pet Name:</label>
        <input type="text" id="petname" name="petname" placeholder="Provide a name for the pet" required>

        <label for="type">Type: <span class="required">*</span></label>
        <select id="type" name="type" required>
            <option value="">--Choose an option--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option>
        </select>

        <label for="description">Description: <span class="required">*</span></label>
        <textarea id="description" name="description" placeholder="Describe the pet briefly" required></textarea>

        <label for="caption">Image Caption: <span class="required">*</span></label>
        <input type="text" id="caption" name="caption" placeholder="Describe the image in one word" required>

        <label for="age">Age (Months): <span class="required">*</span></label>
        <input type="number" id="age" name="age" placeholder="Age of a pet in months" required>

        <label for="location">Location: <span class="required">*</span></label>
        <input type="text" id="location" name="location" placeholder="Location of the pet" required>

        <div class="form-buttons">
            <button type="submit" class="submit-btn">Submit</button>
            <button type="reset" class="clear-btn">Clear</button>
        </div>
    </form>
</main>

<?php
include('includes/footer.inc');  // Include the footer section
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['petname'];
    $type = $_POST['type'];
    $description = $_POST['description'];
    $image_caption = $_POST['caption'];
    $age = $_POST['age'];
    $location = $_POST['location'];
    $image = $_FILES['image']['name'];
    $target_dir = "images/";
    $target_file = $target_dir . basename($image);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        $sql = "INSERT INTO pets (petnname, type, description, image, caption, age, location) 
                VALUES ('$name', '$type', '$description', '$image', '$image_caption', '$age', '$location')";

        if ($conn->query($sql) === TRUE) {
            echo "New pet added successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Sorry, there was an error uploading the image.";
    }

    $conn->close();
}
?>