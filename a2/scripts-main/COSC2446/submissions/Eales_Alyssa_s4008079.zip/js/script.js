function navigateToPage(page) {
    window.location.href = page;
}
