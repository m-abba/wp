<?php
// Include database connection
include('includes/db_connect.inc');

// Get the pet ID from the query string
$petid = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Query the database for the pet details based on the petid
$sql = "SELECT * FROM pets WHERE petid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $petid);
$stmt->execute();
$result = $stmt->get_result();
$pet = $result->fetch_assoc();

// If no pet is found, show an error
if (!$pet) {
    echo "<p>Pet not found!</p>";
    exit;
}

include('includes/header.inc'); // Include the header
include('includes/nav.inc');    // Include the navigation
?>

<div class="wrapper">
    <main class="content-container details-page">
        <div class="pet-details">
            <!-- Pet Image -->
            <img src="images/<?php echo htmlspecialchars($pet['image']); ?>" alt="<?php echo htmlspecialchars($pet['petname']); ?>" class="pet-image">

            <!-- Pet Information Icons -->
            <div class="pet-info">
                <div class="pet-age info-box">
                    <i class="material-icons">schedule</i>
                    <p><?php echo htmlspecialchars($pet['age']); ?> months</p>
                </div>
                <div class="pet-type info-box">
                    <i class="material-icons">pets</i>
                    <p><?php echo htmlspecialchars($pet['type']); ?></p>
                </div>
                <div class="pet-location info-box">
                    <i class="material-icons">place</i>
                    <p><?php echo htmlspecialchars($pet['location']); ?></p>
                </div>
            </div>

            <!-- Pet Name -->
            <h2 class="pet-name"><?php echo htmlspecialchars($pet['petname']); ?></h2>

            <!-- Pet Description -->
            <p class="pet-description"><?php echo htmlspecialchars($pet['description']); ?></p>
        </div>
    </main>
</div>

<?php
include('includes/footer.inc'); // Include the footer
$conn->close(); // Close the database connection
?>
