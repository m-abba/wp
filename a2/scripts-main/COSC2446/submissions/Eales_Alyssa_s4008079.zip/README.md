https://jupiter.csit.rmit.edu.au/~s4008079/wp/a2/
