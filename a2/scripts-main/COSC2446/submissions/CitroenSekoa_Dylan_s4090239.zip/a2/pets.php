<?php include 'includes/header.inc'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pets Victoria</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ysabeau+SC:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<main>
    <h3>Discover Pets Victoria</h3>
    <h4>
        Pets Victoria is a dedicated pet adoption organization based in Victoria, Australia, focused on providing a safe and loving environment for pets in need. With a compassionate approach, Pets Victoria works tirelessly to rescue, rehabilitate, and rehome dogs, cats, and other animals. Their mission is to connect these deserving pets with caring individuals and families, creating lifelong bonds. The organization offers a range of services, including adoption counseling, pet education, and community support programs, all aimed at promoting responsible pet ownership and reducing the number of homeless animals.
    </h4>

    <div class="content">
        <div class="image-table-container">
            <img src="images/pets.jpeg" alt="Running Pets" style="width: 100%; height: auto;"> <!-- Add your image path here -->
            <table>
                <tr>
                    <th>Pet</th>
                    <th>Type</th>
                    <th>Age</th>
                    <th>Location</th>
                </tr>
                <?php
                include 'includes/db_connect.inc';

                $query = "SELECT petid, petname, type, age, location FROM pets WHERE petid > 3"; // Adjust based on your static pets' IDs
                $stmt = $pdo->prepare($query);
                $stmt->execute();
                $dynamicallyFetchedPets = $stmt->fetchAll(PDO::FETCH_ASSOC);

                $staticPets = [
                    [
                        'petid' => 1,
                        'petname' => 'Milo',
                        'type' => 'Cat',
                        'age' => '3 months',
                        'location' => 'Melbourne CBD'
                    ],
                    [
                        'petid' => 2,
                        'petname' => 'Baxter',
                        'type' => 'Dog',
                        'age' => '5 months',
                        'location' => 'Cape Woolamai'
                    ],
                    [
                        'petid' => 3,
                        'petname' => 'Luna',
                        'type' => 'Cat',
                        'age' => '1 month',
                        'location' => 'Ferntree Gully'
                    ]
                ];

                $pets = array_merge($staticPets, $dynamicallyFetchedPets);

                foreach ($pets as $pet): ?>
                    <tr>
                        <td>
                            <a href="details.php?id=<?php echo htmlspecialchars($pet['petid']); ?>"><?php echo htmlspecialchars($pet['petname']); ?></a>
                        </td>
                        <td><?php echo htmlspecialchars($pet['type']); ?></td>
                        <td>
                            <?php
                            if (is_numeric($pet['age'])) {
                                echo htmlspecialchars($pet['age']) . ' months';
                            } else {
                                echo htmlspecialchars($pet['age']);
                            }
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($pet['location']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</main>
<?php include 'includes/footer.inc'; ?>

<script>
    function navigateToPage(dropdown) {
        const selectedPage = dropdown.value;
        if (selectedPage) {
            window.location.href = selectedPage;
        }
    }
</script>
</body>
</html>
