<?php include 'includes/db_connect.inc'?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Details</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
       

        .pet-details {
            text-align: center; 
            margin: 20px;
        }
        .pet-image img {
            max-width: 100%; 
            height: auto; 
        }

        .pet-logos {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        .logo {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 24px;
            margin: 0 10px;
        }

        .logo p {
            margin: 5px 0;
            font-size: 18px;
        }

        .logo-clock {
            margin-right: auto;
        }

        .logo-map {
            margin-left: auto;
        }

        h1 {
            font-size: 32px;
            margin: 20px 0;
        }

        p {
            font-size: 18px;
        }
    </style>
</head>
<body>

    <?php include 'header.inc'; ?>

    <div class="pet-details">
        <?php
        
        $petid = $_GET['id'] ?? null;

        
        $stmt = $pdo->prepare("SELECT * FROM pets WHERE petid = ?");
        $stmt->execute([$petid]);
        $pet = $stmt->fetch();

        if ($pet): ?>
            <div class="pet-image">
              <img src="<?php echo htmlspecialchars($pet['image']); ?>" alt="<?php echo htmlspecialchars($pet['petname']); ?>">
            </div>
            <div class="pet-info">
                <h1><?php echo htmlspecialchars($pet['petname']); ?></h1>
                <div class="pet-logos">
                    <div class="logo logo-clock">
                        <i class="far fa-clock"></i>
                        <p><?php echo htmlspecialchars($pet['age']); ?> months</p>
                    </div>
                    <div class="logo logo-paw">
                        <i class="fas fa-paw"></i>
                        <p><?php echo htmlspecialchars($pet['type']); ?></p>
                    </div>
                    <div class="logo logo-map">
                        <i class="fas fa-map-marker-alt"></i>
                        <p><?php echo htmlspecialchars($pet['location']); ?></p>
                    </div>
                </div>
                <p><?php echo htmlspecialchars($pet['description']); ?></p>
            </div>
        <?php else: ?>
            <h1>Pet Not Found</h1>
        <?php endif; ?>
    </div>

    <?php include 'includes/footer.inc'; ?>
    <script>
        function navigateToPage(dropdown) {
            const selectedPage = dropdown.value;
            if (selectedPage) {
                window.location.href = selectedPage;
            }
        }
    </script>
</body>
</html>