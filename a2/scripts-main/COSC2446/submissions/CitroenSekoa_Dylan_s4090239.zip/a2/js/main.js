function setCurrentPage() {
    const path = window.location.pathname;
    const page = path.split("/").pop(); 
    const dropdown = document.querySelector('select');

    
    for (let option of dropdown.options) {
        if (option.value === page) {
            option.selected = true;
            break;
        }
    }
}

function navigateToPage(dropdown) {
    const selectedPage = dropdown.value;
    if (selectedPage) {
        window.location.href = selectedPage;
    }
}


window.onload = setCurrentPage;
