<!DOCTYPE html>
<html lang="en">
<?php
    include 'includes/header.inc';
    ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pets Victoria</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="index">
    

    <div class="main">
        <div class="text">
            <h1>PETS VICTORIA</h1>
            <h2>WELCOME TO PET ADOPTION</h2>
        </div>
        <img src="images/main.jpg" alt="Dog and Cat">
    </div>

    <?php include 'includes/footer.inc'; ?>
    
    <script>
        function navigateToPage(dropdown) {
            const selectedPage = dropdown.value;
            if (selectedPage) {
                window.location.href = selectedPage;
            }
        }
    </script>
</body>
</html>
