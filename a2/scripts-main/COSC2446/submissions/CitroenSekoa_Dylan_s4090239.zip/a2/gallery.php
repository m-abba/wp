<?php
include 'includes/db_connect.inc';

$pets = [
    1 => ['petname' => 'Milo', 'image' => 'images/cat1.jpeg'],
    2 => ['petname' => 'Baxter', 'image' => 'images/dog1.jpeg'],
    3 => ['petname' => 'Luna', 'image' => 'images/cat3.jpeg'],
];

try {
    $stmt = $pdo->query("SELECT petid, petname, image FROM pets");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $pets[$row['petid']] = [
            'petname' => $row['petname'],
            'image' => $row['image'],
        ];
    }
} catch (PDOException $e) {
    echo "Database query error: " . $e->getMessage();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pets Victoria</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php
    include 'includes/header.inc';
    ?>

    <main class="gallery-main">
        <h2>Pets Victoria has a lot to offer!</h2>
        <h3>For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption into the mainstream. Our work has helped make a difference to the Victorian rescue community and thousands of pets in need of rescue and rehabilitation. But, until every pet is safe, respected, and loved, we all still have big, hairy work to do.</h3>

        <div class="image-grid">
            <?php
            foreach ($pets as $petid => $pet) {
                echo "
                <div class='image-card'>
                    <a href='details.php?id={$petid}'>
                        <img src='{$pet['image']}' alt='{$pet['petname']}'>
                        <div class='overlay'>
                            <div class='text'>Discover more!</div>
                        </div>
                        <p>{$pet['petname']}</p>
                    </a>
                </div>";
            }
            ?>
        </div>
    </main>

    <?php
    include 'includes/footer.inc';
    ?>

    <script>
        function navigateToPage(dropdown) {
            const selectedPage = dropdown.value;
            if (selectedPage) {
                window.location.href = selectedPage;
            }
        }
    </script>
</body>
</html>
