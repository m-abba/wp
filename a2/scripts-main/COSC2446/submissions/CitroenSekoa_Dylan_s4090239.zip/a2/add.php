<?php include 'includes/db_connect.inc'?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add a Pet</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ysabeau+SC:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/header.inc'?>

<div class="form-container">
    <div class="form-title">Add A Pet</div>
    <div class="form-subtitle">You can add a new pet here</div>
    <form action="add.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="petName" class="required">Pet Name:</label>
            <input type="text" id="petName" name="petname" required placeholder="Provide a name for the pet">
        </div>
        <div class="form-group">
            <label for="animalType" class="required">Type:</label>
            <select id="animalType" name="type" required>
                <option value="">--Choose an option--</option>
                <option value="Dog">Dog</option>
                <option value="Cat">Cat</option>
                <option value="Bird">Bird</option>
                <option value="Other">Other</option>
            </select>
        </div>
        <div class="form-group">
            <label for="description" class="required">Description:</label>
            <textarea id="description" name="description" rows="4" required placeholder="Describe the pet"></textarea>
        </div>
        <div class="form-group">
            <label for="imageUpload" class="required">Select an image:</label>
            <input type="file" id="imageUpload" name="image" accept="image/*" required>
            <span class="image-max-size">MAX IMAGE SIZE: 500PX</span>
        </div>
        <div class="form-group">
            <label for="ageInMonths" class="required">Age (months):</label>
            <input type="number" id="ageInMonths" name="age" required placeholder="Age of a pet in months">
        </div>
        <div class="form-group">
            <label for="location" class="required">Location:</label>
            <input type="text" id="location" name="location" required placeholder="Location of the pet">
        </div>
        <div class="form-group button-group">
            <button type="submit" class="submit-btn">Submit</button>
            <button type="reset" class="clear-btn">Clear</button>
        </div>
        <div class="submission-message" style="text-align: center; margin-top: 20px; color: green; display: none;">
            Pet Submitted!
        </div>
    </form>
</div>

<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $petname = $_POST['petname'];
    $type = $_POST['type'];
    $age = $_POST['age'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    
    $target_dir = "images/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

    
    $stmt = $pdo->prepare("INSERT INTO pets (petname, type, age, location, description, image) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$petname, $type, $age, $location, $description, $target_file]);

    
    echo "<script>document.querySelector('.submission-message').style.display = 'block';</script>";
    
    echo "<div class='new-pet-details' style='text-align: center; margin-top: 20px;'>
            <h2>New Pet Added: " . htmlspecialchars($petname) . "</h2>
            <p>Type: " . htmlspecialchars($type) . "</p>
            <p>Age: " . htmlspecialchars($age) . " months</p> <!-- Appended 'months' here -->
            <p>Location: " . htmlspecialchars($location) . "</p>
            <img src='" . htmlspecialchars($target_file) . "' alt='Image of " . htmlspecialchars($petname) . "' style='max-width: 200px;'>
          </div>";}
?>

<?php include 'includes/footer.inc';?>


<script>
    function navigateToPage(dropdown) {
        const selectedPage = dropdown.value;
        if (selectedPage) {
            window.location.href = selectedPage;
        }
    }
 </script>
</body> 
</html>