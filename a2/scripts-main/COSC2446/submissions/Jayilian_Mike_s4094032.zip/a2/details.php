<?php
$title = "Details";
include('includes/header.inc');
include('includes/nav.inc');
if (!empty($_GET['id'])) {
    include('includes/db_connect.inc');
    $petid = $_GET['id'];
    $sql = "SELECT * FROM pets WHERE petid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $petid);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_array();
}
?>
<main>
    <img src="images/<?php echo $row['image']; ?>" alt="<?php echo $row['caption']; ?>" id="details-image">
    <div id="info-container">
        <div class="info-section">
            <span class="material-symbols-outlined alarm-icon">Alarm</span>
            <p>
                <?php 
                $age = $row['age']; 
                if ($age > 12) {
                  echo number_format($age / 12, 1) . " years";
                } else {
                  echo $age . " months";
                }
              ?>
            </p>
        </div>
        <div class="info-section">
            <span class="material-symbols-outlined pets-icon">Pets</span>
            <p><?php echo $row['type']; ?></p>
        </div>
        <div class="info-section">
            <span class="material-symbols-outlined location-icon">Location_On</span>
            <p><?php echo $row['location']; ?></p>
        </div>
    </div>
    <div id="description-container">
        <h3><?php echo $row['petname']; ?></h3>
        <p><?php echo $row['description']; ?></p>
    </div>
</main>
<?php
include('includes/footer.inc');
?>