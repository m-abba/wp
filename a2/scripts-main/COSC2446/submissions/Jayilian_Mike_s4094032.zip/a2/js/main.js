function navigate(element) {
    const selectedPage = element.value;
    if (selectedPage) {
        window.location.href = selectedPage;
    }
}