<?php
$title = "Gallery";
include('includes/header.inc');
include('includes/nav.inc');
include('includes/db_connect.inc');
$sql = "SELECT * FROM pets";
$result = $conn->query($sql);
?>
<main>
  <h3 id="gallery-h3">Pets Victoria has a lot to offer!</h3>
  <p id="gallery-p">
    For almost two decades, Pets Victoria has helped in creating true social
    change by bringing pet adoption into the mainstream. Our work has helped
    make a difference to the Victorian rescue community and thousands of
    pets in need of rescue and rehabilitation. But, until every pet is safe,
    respected, and loved, we all still have big, hairy work to do.
  </p>

  <div class="pet-gallery">
    <?php while ($row = $result->fetch_array()) { ?>
      <div class="pet-box">
        <div class="image-wrapper">
          <img src="images/<?php echo $row['image']; ?>" alt="<?php echo $row['caption']; ?>">
          <div class="overlay">
            <span class="material-symbols-outlined Discover-icon">Search</span>
            <u><a href="details.php?id=<?php echo $row['petid']; ?>">Discover More!</a></u>
          </div>
        </div>
        <h3><?php echo $row['petname']; ?></h3>
      </div>
    <?php } ?>
  </div>
</main>
<?php
include('includes/footer.inc');
?>