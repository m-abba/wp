<?php
$title = "Home";
include('includes/header.inc');
include('includes/nav.inc');
?> 
    <main id="index-main">
      <div class="text-container">
        <h1 id="index-h1">PETS VICTORIA</h1>
        <h2 id="index-h2">
          WELCOME TO PET <br>
          ADOPTION
        </h2>
      </div>
      <img src="images/main.jpg" alt="Main Image" class="main-image">
    </main>
<?php
include('includes/footer.inc');
?>