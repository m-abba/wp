<?php
$title = "Add More";
include('includes/header.inc');
include('includes/nav.inc');

if (isset($_POST['petname'])) {
  $petname = $_POST['petname'];
  $description = $_POST['description'];
  $caption = $_POST['caption'];
  $age = $_POST['age'];
  $location = $_POST['location'];
  $type = $_POST['type'];
  $image = $_FILES['image']['name'];
  $temp = $_FILES['image']['tmp_name'];
  $error = $_FILES['image']['error'];
  $caption = $_POST['caption'];

  include('includes/db_connect.inc');

  $sql = "INSERT INTO pets (petname, description, image, caption, age , location, type) VALUES (?, ?, ?, ?, ?, ?, ?)";

  $stmt = $conn->prepare($sql);

  if (!$stmt) {
    echo "Error: " . $conn->error;
  }
  $stmt->bind_param("ssssdss", $petname, $description, $image, $caption, $age, $location, $type);

  $stmt->execute();

  if ($stmt->affected_rows > 0) {
    move_uploaded_file($temp, 'images/' . $image);
    echo "Pet added successfully!";
  } else {
    echo "Error: " . $conn->error;
  }
}

?>
<main>
  <h3 id="add-h3">Add a pet</h3>
  <p id="add-p">You can add a new pet here</p>

  <form action="add.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label class="required">Pet Name:</label>
      <input
        type="text"
        placeholder="Provide a name for the pet"
        name="petname"
        required>
    </div>

    <div class="form-group">
      <label class="required">Type:</label>
      <select name="type" required>
        <option value="">--Choose an option--</option>
        <option value="dog">Dog</option>
        <option value="cat">Cat</option>
      </select>
    </div>

    <div class="form-group">
      <label class="required">Description</label>
      <textarea
        rows="2"
        placeholder="Describe the pet briefly"
        name="description"
        required></textarea>
    </div>

    <div class="form-group">
      <label class="required">Select an Image:</label>
      <input type="file" id="image" name="image" required>
      <i>Max image size: 500px</i>
    </div>

    <div class="form-group">
      <label class="required">Image Caption:</label>
      <input
        type="text"
        placeholder="describe the image in one word"
        id="caption"
        name="caption"
        required>
    </div>

    <div class="form-group">
      <label class="required">Age (months):</label>
      <input
        type="number"
        placeholder="Age of a pet in months"
        id="age"
        name="age"
        min="0"
        required>
    </div>

    <div class="form-group">
      <label class="required">Location:</label>
      <input
        type="text"
        placeholder="Location of the pet"
        id="location"
        name="location"
        required>
    </div>
    <div class="buttons">
      <button type="submit" class="submit-button">
        <span class="material-symbols-outlined submit-icon">
          add_task
        </span>
        Submit
      </button>

      <button type="reset" class="clear-button">
        <span class="material-symbols-outlined clear-icon"> close </span>
        Clear
      </button>
    </div>
  </form>
</main>
<?php
include('includes/footer.inc');
?>