
<?php
$title = "Insert";
include('Includes/header.inc');
include('Includes/nav.inc');
include('Includes/db_connect.inc');


foreach ($_POST as $key => $val) {
    $$key = trim($val);
}
$image = $_FILES['image']['name'];
$temp = $_FILES['image']['tmp_name'];
$error = $_FILES['image']['error'];

$sql = "INSERT INTO pets(petname,description,caption,age,type,location,image) VALUES (?,?,?,?,?,?,?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    exit("An error occurred");
}

$stmt->bind_param('sssisss',$petname, $description, $caption, $age, $type, $location, $image);

if (!$stmt->execute()) {
    echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error; // Added error handling for execution failure
} else {
    echo '<p>New record successfully inserted into the database</p>';
    
    // Move uploaded file
    if (move_uploaded_file($temp, 'images/' . $image)) {
        echo "<p>Image moved to folder</p>";
    } else {
        echo "<p>Image not moved to folder</p>";
    }
}

$stmt->close();
$conn->close();

include('Includes/footer.inc');

?>