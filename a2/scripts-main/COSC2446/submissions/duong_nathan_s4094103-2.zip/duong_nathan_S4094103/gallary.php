<?php
    $title = 'Gallery';

    include('Includes/header.inc');
    include('Includes/nav.inc');
    include('Includes/db_connect.inc');
    ?>
    <p id="bold">Pets Victoria has alot to offer!</p>            
    <p>For almost two decades, Pets Victoria has helped in creating true social change by bringing pet adoption into the mainstream.               
     Our work has helped make a difference to the Victorian community and thousands of pets in need of rescue and rehabilitation. 
     But, until every pet is safe, respected, and loved, we all still have big, hairy work to do.</p>

    <?php

    //SQL query to select all pets from the table
    $sql = "SELECT * FROM pets";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo '<div class="grid-container">';
        
        //Loops through each pet and output the necessary information
        while ($row = $result->fetch_assoc()) {
            $petid = $row['petid'];
            $petname = $row['petname'];
            $type = $row['type'];
            $age = $row['age'];
            $description = $row['description'];
            $image = $row['image'];
            $location = $row['location'];
            
            echo '<div class="info">';
            echo '<img src="images/' . $image . '" alt="' . $petname . '" class="petImage">';
            echo '<div class="container">';
            echo '<div class="p">' . $petname . '</div>';
            echo '</div>';
            echo '<div class="overlay">';
            echo '<img src="images/search.png" alt="searchIcon" class="searchIcon">';
            echo '<a href="details.php?id=' . urlencode($row["petid"]) . '"><div class="text">Discover More!</div></a>';
            echo '</div>';
            echo '</div>';
        }
        
        echo '</div>';
    } else {
        echo '<p>No pets found.</p>';
    }

    $conn->close();
?>




<?php
    include('Includes/footer.inc');
?>
