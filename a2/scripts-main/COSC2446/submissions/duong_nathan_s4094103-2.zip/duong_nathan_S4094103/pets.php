<?php
    $title = 'Pets';
    include('Includes/header.inc');
    include('Includes/nav.inc');  
    
?>
    
        <p id="bold">Discover Pets Victoria</p>
        <p>Pets victoria is a dedicated pet adoption organization based in Victoria, Australia, focused on providing a safe and loving environment for pets in need. 
            With a compassionate approach, Pets Victoria works tirelessly to rescure, rehabilitate, and rehome dogs, cats and other animals. Their mission is to connect these
            deserving pets with caring individuals and families, creating lifelong bonds. The organization offers a range of services, including adoption counseling, pet education,
            and community support programs, all aimed at promoting responsible pet ownership and reducing the number of homeless animals.
        </p>

        <img src="images/pets.jpeg" alt="Pets">
        <!-- Table to display the pets -->
        <table id="tb">
            <tr id="label">
                <th>Pet</th>
                <th>Type</th>
                <th>Age</th>
                <th>location</th>
                </tr>
                <?php
                    //connect
                    include('Includes/db_connect.inc');
            

                    $sql = "select * from pets";

                    $result = $conn->query($sql);
                    //loop through the table of results printing each row
                    if ($result->num_rows > 0) {

                        while ($row = mysqli_fetch_array($result)) {
                            print "<tr>\n";
                            print "<td><a href='details.php?id=" . urlencode($row['petid']) . "'>{$row['petname']}</a></td>\n";
                            print "<td>{$row['type']}</td>\n";
                            print "<td>{$row['age']} Months</td> \n";
                            print "<td>{$row['location']}</td>\n";
                            print "</tr>\n";
                        }
                    } else {
                        echo "<tr><td colspan=4>0 results</td></tr>";
                    }
                    ?>
        </table>






    <?php
    include('Includes/footer.inc');
    ?>
    