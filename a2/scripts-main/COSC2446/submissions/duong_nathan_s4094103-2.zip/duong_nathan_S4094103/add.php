<?php
    $title = 'Form';
    include('Includes/header.inc');
    include('Includes/nav.inc');  
?>
        
            <p id="bold">Add a pet</p>
            <p>YOU CAN ADD A NEW PET HERE</p>
            <!-- Form -->
            <form method = "post" action="process_new_pet.php" enctype="multipart/form-data">
                <label for="pname">Pet Name:</label> <span>*</span> <br>
                <input type="text" id="pname" name="petname" placeholder="Provide a name for the pet" required><br>
                <label for="types">Type:</label> <span>*</span><br>
                <select id="types" name="type" required>
                    <option value="" disabled selected>Choose an option</option>
                    <option value="dog">Dog</option>
                    <option value="cat">Cat</option>
                    <option value="rabbit">Rabbit</option>
                    <option value="bird">Bird</option>
                </select>
                <br>
                <label for="description">Description:</label> <span>*</span><br>
                <textarea name="description" id="description" placeholder="Describe the pet briefly" required></textarea><br>
                <label for="image">Select an image:</label> <span>*</span>
                <input type="file" id="image" name="image" required> <span>Max Image Size 500px</span><br>
                <label for="imgCaption">Image Caption:</label> <span>*</span><br>
                <input type="text" id="imgCaption" name="caption" placeholder="Describe the image in one word" required><br>
                <label for="age">Age(Months)</label> <span>*</span><br>
                <input type="number" id="age" name="age" min="1" placeholder="Age of a pet in months" required><br>
                <label for="location">Location</label> <span>*</span><br>
                <input type="text" id="location" name="location" placeholder="Location of the pet" required><br>
                <button id="submit" class="button" type="submit">
                    <img src="images/check.png" alt="check" id="icons">Submit</button> <br>
                <button id="clear" class="button" type="reset" name="clear">
                    <img src="images/clear.png" alt="clear" id="clearIcon">Clear</button> <br>
            </form>
            <br>
            <br>
            <br>

        


<?php
    include('Includes/footer.inc');
    ?>