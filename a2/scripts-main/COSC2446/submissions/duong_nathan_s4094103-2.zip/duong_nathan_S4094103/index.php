<?php
    $title = 'Main';
    include('Includes/header.inc');
    include('Includes/nav.inc');      
?>
<!-- Main page -->
    <main>
        <img src="images/main.jpg" alt="main" id="indexImage">
        <br>
        <h1>Pets Victoria</h1>
        <h2>WELCOME TO PET ADOPTION</h2>
        <br>
        
    </main>
    

<?php
    include('Includes/footer.inc');
    ?>
    

