<?php
include('Includes/header.inc');
include('Includes/nav.inc');
?>

<?php
$image = '';
if (!empty($_GET['id'])) {
    include('Includes/db_connect.inc');
    //Gets the pet id
    $id = $_GET['id'];

    $sql = "select * from pets where petid = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("i", $id);

    $stmt->execute();

    $result = $stmt->get_result();

    //Gets the pet details based on the pet id
    if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $petname = $row['petname'];
            $type = $row['type'];
            $age = $row['age'];
            $description = $row['description'];
            $image = $row['image'];
            $location = $row['location'];
        }
    }
    
    $conn->close();
}
else{
    echo "No pet selected";
}
?>
            <!-- Displays the pet details -->
            <img src="images/<?php echo htmlspecialchars($image); ?>" alt="pet image" id="detailImage"> <br>
            <br>
            <div class = "block">
            <img src="images/age.png" alt="age icon" id="ageIcon">
            <p><?php echo $age;?> Months</p>
            </div>

            <div class = "block">
            <img src="images/pets.png" alt="pet icon" id="petIcon">
            <p><?php echo $type;?></p>
            </div>

            <div class = "block">
            <img src="images/location.png" alt="location icon" id="locationIcon">
            <p><?php echo $location;?></p>
            </div>
            
            <p id="bold"><?php echo $petname; ?></p>
            <p><?php echo htmlspecialchars($description); ?></p>

            <br>












<?php
include('Includes/footer.inc');
?>