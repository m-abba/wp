function doMenu() {
	let menu = document.getElementById("menu");
	let optionNumber = menu.options.selectedIndex;
	let url = menu.options[optionNumber].value;
	location.href = url;
}

function homePage() {
	location.href = "https://jupiter.csit.rmit.edu.au/~s4094103/wp/a2/";
}