<?php
$title = "Add Pets";
include('includes/header.inc');
include('includes/nav.inc');
?>
<main>
  <h3>Add a pet</h3>
  <p>You can add a new pet here</p>
  <form action="process_add_pet.php" method="POST" enctype="multipart/form-data">
    <label for="petName" class="required">Pet Name:</label>
    <input id="petName" type="text" name="petName" required placeholder="Provide a name for the pet">
    <label for="type" class="required">Type: </label>
    <select name="type" id="type" required>
      <option value="" disabled selected>--Choose an option--</option>
      <option value="cat">Cat</option>
      <option value="dog">Dog</option>
    </select>
    <label for="Description" class="required">Description</label>
    <textarea name="Description" required placeholder=" Describe the pet briefly" id="Description"></textarea>
    <div class="file-input">
      <label for="file" class="required">Select An Image:</label>
      <input type="file" name="image" id="file" required>
    </div>
    <label for="imgCaption" class="required">Image Caption</label>
    <input type="text" name="imgCaption" id="imgCaption" required placeholder="Describe the image in one word">
    <br>
    <label for="Age" class="required"> Age (Months): </label>
    <input type="number" name="Age" id="Age" required placeholder=" Age of a pet in months">
    <label for="Location" class="required">Location: </label>
    <input type="text" name="Location" id="Location" required placeholder=" Location of the pet">
    <div class="button_container">
      <button type="submit">
        <span class="material-symbols-outlined">
          add_task
        </span>
        Submit
      </button>
      <button type="reset">
        <span class="material-symbols-outlined">
          close
        </span>
        Clear
      </button>
    </div>
  </form>
  <br>
</main>
<?php
include('includes/footer.inc');
?>