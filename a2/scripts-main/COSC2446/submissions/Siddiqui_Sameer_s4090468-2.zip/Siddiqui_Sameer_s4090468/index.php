<?php
$title = "Home";
$id = "background_home";
include('includes/header.inc');
include('includes/nav.inc');
?>
<main>
  <div class="content-container">
    <div id="main_text">
      <h1>Pets Victoria</h1>
      <h2>WELCOME TO PET ADOPTION</h2>
    </div>
    <img id="home_image" src="images/main.jpg" alt="cat and dog image">
  </div>
</main>
<?php
include('includes/footer.inc');
?>