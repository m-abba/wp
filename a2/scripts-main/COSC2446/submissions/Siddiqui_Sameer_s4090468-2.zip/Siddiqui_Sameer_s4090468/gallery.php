<?php
$title = "Gallery";
include('includes/header.inc');
include('includes/nav.inc');
include('includes/db_connect.inc');
?>
<main>
  <h3>Pets Victoria has a lot to offer!</h3>
  <p>
    For almost two decades, Pet Victoria has helped in creating true social
    change by bringing pet adoption intot he mainstream. Our work has helped
    make a difference to the Victorian rescue community and thousands of
    pets in need of rescue and rehabilitation. But, until every pet is safe,
    respected, and loved, we all still have big, hairy work to do.
  </p>
  <?php
  //Query which gets petid, petname etc from pets table
  $sql = "SELECT petid, petname, image, caption FROM pets";
  //Result of the query stored in $result
  $result = $conn->query($sql);
  //Card Container for the imgs
  echo "<div class='card-container'>";
  //While loop which prints all details for the pets table
  while ($row = $result->fetch_assoc()) {
    echo "<div class='card'>";
    //Link to details page
    //Passes petid to details php
    echo "<a href='details.php?petid=" . urlencode($row['petid']) . "'>";
    //Row array which adds all the details to the card
    echo "<img src='" . $row['image'] . "' alt='" . $row['caption'] . "'>"; // Using caption for alt
    echo "<i class='material-symbols-outlined'>search</i>";
    echo "<span class='invis_text'>Discover More!</span>";
    echo "</a>";
    echo "<p class='petname'>" . $row['petname'] . "</p>";
    echo "</div>";
  }
  echo "</div>";
  ?>
</main>
<?php
include('includes/footer.inc');
?>