<?php
//Connect to db server
include('includes/db_connect.inc');

$petname = $_POST['petName'];
$description = $_POST['Description'];
$image = 'images/' . $_FILES['image']['name'];
$caption = $_POST['imgCaption'];
$age = $_POST['Age'];
$location = $_POST['Location'];
$type = $_POST['type'];

//Define query 
$sql = "INSERT INTO pets (petname, description, image, caption, age, location, type) VALUES
(?,?,?,?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

//Bind parameters
$stmt->bind_param("ssssdss", $petname, $description, $image, $caption, $age, $location, $type);

//Execute query
$stmt->execute();

//Check if record created, then upload image
if ($stmt->affected_rows > 0) {
    move_uploaded_file($_FILES['image']['tmp_name'], 'images/' . $_FILES['image']['name']);
    include('includes/header.inc');
    include('includes/nav.inc');
    echo "<h3>Record created successfully</h1>";
    echo "Record created successfully";
    include('includes/footer.inc');
}else {
    echo "Failed to upload record";
}

$conn->close();
?>