<?php
$title = "Details";
include('includes/header.inc');
include('includes/nav.inc');
?>

<?php
if (!empty($_GET['petid'])) {
    include('includes/db_connect.inc');

    $petid = $_GET['petid'];

    $sql = "select * from pets where petid = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $petid);

    $stmt->execute();

    $result = $stmt->get_result();


    if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_array($result)) {
            print "<img class='img-details' src='" . $row["image"] . "' alt='" . $row['caption'] . "'>";
            print "<div class='details'>";
            print "<div class='icon-text'>";
            print "<span class='material-symbols-outlined' id = 'alarm_icon'>alarm</span>";
            print "<p>" . $row["age"] . " Months</p>";
            print "</div>";
            print "<div class='icons-text'>";
            print "<span class='material-symbols-outlined' id = 'pet_icon'>Pets</span>";
            print "<p>" . $row["type"] . " </p>";
            print "</div>";
            print "<div class='icons-text'>";
            print "<span class='material-symbols-outlined' id = 'location_icon'>location_on</span>";
            print "<p>" . $row["location"] . "</p>";
            print "</div>";
            print "</div>";
            print "<h3>" . $row["petname"] . "</h3>";
            print "<p>" . $row["description"] . "</p>";
        }
    }

    $conn->close();
}
?>

<?php
include('includes/footer.inc');
?>