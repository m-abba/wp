function dropdownFunction(){
    let x = document.getElementById("dropdown").value;
    if(x == "home"){
        window.location.href = "index.php";
    } else if(x == "about"){
        window.location.href = "pets.php";
    } else if (x == "add_more"){
        window.location.href = "add.php";
    } else if (x == "gallery"){
        window.location.href = "gallery.php";
    }
};