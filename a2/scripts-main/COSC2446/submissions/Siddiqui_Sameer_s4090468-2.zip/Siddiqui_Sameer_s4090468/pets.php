<?php
$title = "About";
include('includes/header.inc');
include('includes/nav.inc');
?>
<main>
  <div id="pet_text">
    <h3>Discover Pets Victoria</h3>
    <p>
      Pets Victoria is a dedicated pet adoption organization based in
      Victoria, Australia, focused on providing a safe and loving
      environment for pets in need. With a compassionate approach, Pets
      Victoria works tirelessly to rescue, rehabilitate and rehome dogs,
      cats and other animals. Their mission is to connect these deserving
      pets with caring individuals and families, creating lifelong bonds.
      The organization offers a range of services, including adoption
      counseling, pet education, and community support programs, all aimed
      at promoting responsible pet ownership and reducing the number of
      homeless animals.
    </p>
  </div>
  <div class="image_table_container">
    <img src="images/pets.jpeg" alt="Image of dogs and cats running">
    <table>
      <tr>
        <th>Pet</th>
        <th>Type</th>
        <th>Age</th>
        <th class="last_column">Location</th>
      </tr>
      <?php
      //connect to database 
      include('includes/db_connect.inc');

      //Selects all rows from pets table
      $sql = "select * from pets";

      //Executes SQL query on connected database and stores result in variable
      $result = $conn->query($sql);

      //Statement checks if query returned any rows. 
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
          //Creates table row
          print "<tr>\n";
          //Contains hyperlink to details.php passing petid as URL parameter
          print "<td><a href='details.php?petid=" . urlencode($row['petid']) . "'>{$row['petname']}</a></td>\n";
          print "<td>{$row['type']}</td>\n";
          print "<td>{$row['age']} Months</td>\n";
          print "<td class='last_column'>{$row['location']}</td>\n";
          print "</tr>\n";
        }
      } else {
        // Display a message when no pets are available
        echo "<tr><td colspan='4'>No pets available</td></tr>";
      }
      ?>
    </table>
  </div>
</main>
<?php
//Closes database connection
$conn->close();
include('includes/footer.inc');
?>