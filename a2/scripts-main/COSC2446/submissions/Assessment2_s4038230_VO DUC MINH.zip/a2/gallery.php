<?php
$title = "Assessment 2.4";
include "include/header.inc";
include "include/nav.inc";
include "include/db_connect.inc";
// Fetch pets data
$sql = "SELECT * FROM pets";
$result = mysqli_query($conn, $sql);
$pets = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Free the result and leave connection open for other pages
mysqli_free_result($result);
?>

<main id="mainbody-4">
  <div id="fontbody7">
    <p>Pets Victoria has a lot to offer!</p>
  </div>

  <div id="fontbody8">
    <b>
      For almost two decades, Pets Victoria has helped in creating true
      social change by bringing pet adoption into the mainstream. Our work
      has helped make a difference to the Victorian rescue community and
      thousands of pets in need of rescue and rehabilitation. But, until
      every pet is safe, respected, and loved, we all still have big, hairy
      work to do.
    </b>
  </div>
  <?php foreach ($pets as $pet): ?>
  <div class="details-link">
    <div class="imgbox">
      <a href="details.php?petid=<?php echo $pet['petid']; ?>">
        <img class="fade" src="images/<?php echo htmlspecialchars($pet['image']); ?>" />
        <p><?php echo htmlspecialchars($pet['petname']); ?></p>
        <div class="overlay">
          <span><img src="images/blacksearchingtool.png" />
            <p>Discover more!</p>
          </span>
      </a>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
</main>
<?php
include "include/footer.inc";
?>