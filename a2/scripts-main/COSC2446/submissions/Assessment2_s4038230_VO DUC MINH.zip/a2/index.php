<?php
$title = "Assessment 2.5";
include "include/header.inc";
include "include/nav.inc";
?>
<main id="mainbody-1">
    <img id="mainpicture-1" src="images/main.jpg" alt="Dog and cat" />

    <div class="fontbody1">
        <p>PETS VICTORIA</p>
    </div>

    <div class="fontbody2">
        <p>WELCOME TO PET</p>
        <p>ADOPTION</p>
    </div>
</main>
<?php
include "include/footer.inc";
?>