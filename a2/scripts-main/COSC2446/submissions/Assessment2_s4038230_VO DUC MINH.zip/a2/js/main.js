//This makes all the websites can be directed to each other within user's input
function handleSelection(source) {
  window.location = source;
}
