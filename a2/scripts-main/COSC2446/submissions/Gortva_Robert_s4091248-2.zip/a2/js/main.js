function toggleMenu() {
    const menuDropdown = document.getElementById('menuDropdown');
    const menuLinks = document.getElementById('menuLinks');

    if (menuDropdown.value === 'menu') {
        menuLinks.classList.add('show');
    } else {
        menuLinks.classList.remove('show');
    }
}
  