<?php
include('include/header.inc');
include('include/nav.inc');
?>

<!-- main section start  -->
<main class="gallery">
    <h3>Pets Victoria has a lot to offer!</h3>
    <p class="para">FOR ALMOST TWO DECADES, PETS VICTORIA HAS HELPED IN CREATING TRUE SOCIAL CHANGE BY BRINGING PET ADOPTION INTO THE MAINSTREAM. OUR WORK HAS HELPED MAKE A
        DIFFERENCE TO THE VICTORIAN RESCUE COMMUNITY AND THOUSANDS OF PETS IN NEED OF RESCUE AND REHABILITATION. BUT, UNTIL EVERY PET IS SAFE, RESPECTED, AND LOVED, WE ALL
        STILL HAVE BIG, HAIRY WORK TO DO.</p>
    <?php
    include('include/db_connect.inc');

    // SQL query to fetch all pets (make sure this query includes the petid)
    $sql = "SELECT petid, image, petname FROM pets";
    $result = $conn->query($sql);
    ?>

    <div class="outer">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="gal-card">
                <div class="card-content">
                    <a href="details.php?petid=<?php echo $row['petid']; ?>">
                        <div class="image-overlay">
                            <img src="<?php echo $row['image']; ?>" alt="gallery" class="hover-image">
                            <div class="overlay-text">Discover more!</div>
                        </div>
                    </a>
                    <h3 class="name"><?php echo $row['petname']; ?></h3>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

</main>
<div class="menu-links" id="menuLinks">
    <a href="index.php">Home</a>
    <a href="pets.php">Pets</a>
    <a href="gallery.php">Gallery</a>
    <a href="add.php">Add a pet</a>
</div>
<!-- footer start  -->
    <?php
    include('include/footer.inc')
    ?>
</html>