CREATE DATABASE petsvictoria;
USE petsvictoria;
CREATE TABLE `pets` (
  `petid` int (11) NOT NULL AUTO_INCREMENT,
  `petname` varchar (255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar (255) NOT NULL,
  `caption` varchar (255) NOT NULL,
  `age` double NOT NULL,
  `location` varchar (255) NOT NULL,
  `type` varchar (255) NOT NULL,
  PRIMARY KEY (`petid`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

--  incase needed
-- INSERT INTO pets (pet_name, pet_type, pet_description, pet_image, image_caption, age, location) 
-- VALUES
-- ('Bella', 'Dog', 'Friendly golden retriever with lots of energy.', 'uploads/bella.jpg', 'Happy Bella', 24, 'Melbourne'),
-- ('Whiskers', 'Cat', 'Playful tabby cat, loves attention.', 'uploads/whiskers.jpg', 'Whiskers curled up', 12, 'Geelong'),
-- ('Max', 'Dog', 'Calm and obedient German shepherd.', 'uploads/max.jpg', 'Max on a walk', 48, 'Sydney'),
-- ('Luna', 'Cat', 'Independent and curious black cat.', 'uploads/luna.jpg', 'Luna exploring', 18, 'Ballarat'),
-- ('Charlie', 'Dog', 'Affectionate and playful beagle, loves to run.', 'uploads/charlie.jpg', 'Charlie running in the park', 36, 'Bendigo');


select *
from petsvictoria.pets;