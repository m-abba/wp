<?php
include('include/header.inc')
?>
<?php
include('include/nav.inc')
?>
    <!-- main section start  -->
    <main class="pets">
        <h3>Discover Pets Victoria</h3>
        <p class="para">PETS VICTORIA IS A DEDICATED PET ADOPTION ORGANIZATION BASED IN VICTORIA, AUSTRALIA, FOCUSED ON
            PROVIDING A SAFE AND LOVING ENVIRONMENT FOR PETS IN NEED. WITH A
            COMPASSIONATE APPROACH, PETS VICTORIA WORKS TIRELESSLY TO RESCUE, REHABILITATE, AND REHOME DOGS, CATS, AND
            OTHER ANIMALS. THEIR MISSION IS TO CONNECT THESE
            DESERVING PETS WITH CARING INDIVIDUALS AND FAMILIES, CREATING LIFELONG BONDS. THE ORGANIZATION OFFERS A
            RANGE OF SERVICES, INCLUDING ADOPTION COUNSELING, PET
            EDUCATION, AND COMMUNITY SUPPORT PROGRAMS, ALL AIMED AT PROMOTING RESPONSIBLE PET OWNERSHIP AND REDUCING THE
            NUMBER OF HOMELESS ANIMALS.</p>
        <div class="pet-parent">
            <div class="child"><img src="./images/pets.jpg" alt="pets"></div>
            <div class="child">
                <table>
                    <thead class="table-heading">
                        <tr>
                            <th>Pet</th>
                            <th>Type</th>
                            <th>Age</th>
                            <th>Location</th>
                        </tr>
                    </thead>

                    <?php
                        //connect
                        include('include/db_connect.inc');

                        $sql = "select * from pets";

                        $result = $conn->query($sql);
                        //loop through the table of results printing each row
                        if ($result->num_rows > 0) {

                            while ($row = $result->fetch_array()) {
                                print "<tr>\n";
                                // in urlencode will change when you click on the actual data and take you to the details page
                                // after $row, comes column name
                                print "<td><a href='details.php?petid=" . urlencode($row['petid']) . "'>{$row['petname']}</a></td>\n";
                                
                                print "<td><a href='details.php?petid=" . urlencode($row['petid']) . "'>{$row['type']}</a></td>\n";
                                print "<td><a href='details.php?petid=" . urlencode($row['petid']) . "'>{$row['age']}</a></td>\n";
                                print "<td><a href='details.php?petid=" . urlencode($row['petid']) . "'>{$row['location']}</a></td>\n";


                                // print "<td>{$row['published']}</td>\n";
                                // print "</tr>\n";
                            }
                        } else {
                            echo "<tr><td colspan=4>0 results</td></tr>";
                        }
                        ?>                   
                    <!-- <tbody>
                        <tr>
                            <td>M</td>
                            <td>Dog</td>
                            <td>12 Month</td>
                            <td>MELBOURNE CBD</td>
                        </tr>
                        <tr>
                            <td>Bella</td>
                            <td>Dog</td>
                            <td>8 Month</td>
                            <td>CAPE WOOLAMAI</td>
                        </tr>
                        <tr>
                            <td>Shadow</td>
                            <td>Cat</td>
                            <td>3 Month</td>
                            <td>FERNTREE GULLY</td>
                        </tr>
                        <tr>
                            <td>Luna</td>
                            <td>Dog</td>
                            <td>5 Month</td>
                            <td>MARYSVILLE</td>
                        </tr>
                        <tr>
                            <td>Rocky</td>
                            <td>Dog</td>
                            <td>24 Month</td>
                            <td>GRAMPIANS</td>
                        </tr>
                        <tr>
                            <td>Whiskers</td>
                            <td>Cat</td>
                            <td>1 Month</td>
                            <td>CARLTON</td>
                        </tr> -->
                    <!-- </tbody> -->
                </table>
            </div>
        </div>
    </main>
    <div class="menu-links" id="menuLinks">
        <a href="index.php">Home</a>
        <a href="pets.php">Pets</a>
        <a href="gallery.php">Gallery</a>
        <a href="add.php">Add a pet</a>
    </div>
    <!-- footer start  -->
    <?php
    include('include/footer.inc')
    ?>

</html>