<?php
include('include/header.inc')
?>
<?php
include('include/nav.inc')
?>
    </header>
    <!-- main section start  -->
    <main class="homepage">
<div class="parent">
    <div class="content">
        <h1>Pets Victoria</h1>
        <h2 class="tagline">Welcome To Pet <br> Adoptation</h2>
    </div>
    <div class="hero">
        <img src="./images/main.jpg" alt="hero-image">
    </div>
</div>
    </main>
    <div class="menu-links" id="menuLinks">
        <a href="index.php">Home</a>
        <a href="pets.php">Pets</a>
        <a href="gallery.php">Gallery</a>
        <a href="add.php">Add a pet</a>
    </div>
    <!-- footer start  -->

<?php
include('include/footer.inc')
?>
    

</html>