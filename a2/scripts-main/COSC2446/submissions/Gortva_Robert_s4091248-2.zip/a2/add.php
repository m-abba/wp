<?php
include('include/header.inc')
?>
<?php
include('include/nav.inc')
?>

<?php include('include/db_connect.inc'); ?>


    <!-- main section start  -->
    <main>
        <h3>Add a pet</h3>
        <p class="para">You CAN ADD A NEW PET HERE</p>
        <form action="/wp/a2/add_pet.php" method="post" enctype="multipart/form-data">
            <!-- Pet Name Field -->
            <div>
              <label for="petname">Pet Name:<span class="required">*</span></label>
              <input class="inp"  type="text" id="petname" name="petname" placeholder="Provide a name for the pet" required>
            </div>
          
            <!-- Pet Type Field -->
            <div>
              <label for="type">Pet Type:<span class="required">*</span></label>
              <select class="inp" id="type" name="type" required>
                <option value="cat">Cat</option>
                <option value="dog">Dog</option>
              </select>
            </div>
          <!-- Pet Description -->
          <div>
            <label for="description">Description:<span class="required">*</span></label>
            <input class="inp"  type="text" id="description" name="description" placeholder="Describe the pet briefly" required>
          </div>
            <!-- Image Upload Field -->
            <div>
              <label for="image">Select an Image:<span class="required">*</span></label>
              <input type="text" id="image" name="image" accept="image/*" required>
            </div>
            <!-- Image Caption-->
          <div>
            <label for="caption">Image Caption:<span class="required">*</span></label>
            <input class="inp"  type="text" id="caption" name="caption" placeholder="describe the image in one word" required>
          </div>
          <!-- Age-->
          <div>
            <label for="age">Age (months):<span class="required">*</span></label>
            <input class="inp"  type="int" id="age" name="age" placeholder="Age of a pet in months" required>
          </div>
          <!-- location-->
          <div>
            <label for="location">Location:<span class="required">*</span></label>
            <input class="inp"  type="text" id="location" name="location" placeholder="Location of the pet" required>
          </div>
          
          
            <!-- Submit Button -->
            <div class="btn">
              <!-- Submit Button -->
      <button class="sub" type="submit", value = "Submit">
        <span class="material-symbols-outlined">
            <!-- task_alt -->
            </span> Submit
      </button>

      <!-- Clear Button -->
      <button class="clear" type="button" onclick="document.getElementById('pet-form').reset();">
        <span class="material-icons">clear</span> Clear
      </button>
            </div>
          </form>
          
    </main>
    <div class="menu-links" id="menuLinks">
        <a href="index.php">Home</a>
        <a href="pets.php">Pets</a>
        <a href="gallery.php">Gallery</a>
        <a href="add.php">Add a pet</a>
    </div>
    <!-- footer start  -->
        <?php
    include('include/footer.inc')
    ?>
</body>



