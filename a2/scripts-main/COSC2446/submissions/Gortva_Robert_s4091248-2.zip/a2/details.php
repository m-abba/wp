<?php
// Include necessary files for database connection and common header
include('include/header.inc');
include('include/nav.inc');


if (!empty($_GET['petid']) && is_numeric($_GET['petid'])) {
    include('include/db_connect.inc');

    $petid = intval($_GET['petid']); // Validate and cast to integer

    // SQL query to fetch the pet details by ID
    $sql = "SELECT petname, age, type, location, description, image FROM pets WHERE petid = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("SQL Error: " . $conn->error);
    }

    // Bind the petid parameter and execute
    $stmt->bind_param("i", $petid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $petname = $row['petname'];
            $age = $row['age'];
            $type = $row['type'];
            $location = $row['location'];
            $description = $row['description'];
            $image = $row['image'];
        }
    } else {
        echo "No pets found with this ID.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid pet ID.";
}
?>

<head>
    <link rel="stylesheet" href="css/style.css">
</head>

<div class="container" style="text-align: center;"> <!-- Center the text inside the container -->
    <h1>About this pet</h1>

    <div class="image-container" style="display: flex; justify-content: center; margin: 20px 0;">
        <img src="<?php echo $image; ?>" alt="Picture of <?php echo $petname; ?>" class="image-pet" style="width: 350px; height: 350px; border-radius: 50%; object-fit: cover;"> <!-- Circular image -->
    </div>

    <!-- Pet Info Container with Flexbox -->
    <div class="pet-info" style="display: flex; justify-content: space-between; margin-top: 20px; padding: 0 50px;"> <!-- Added padding for spacing -->
        <div class="pet-info-item" style="text-align: center;">
            <img src="images/icon-clock1.png" alt="Clock Icon" style="width: 30px; height: auto;">
            <div><?php echo $age; ?> months</div> <!-- Changed span to div for consistency -->
        </div>
        <div class="pet-info-item" style="text-align: center;">
            <img src="images/icon-paw1.png" alt="Paw Icon" style="width: 30px; height: auto;">
            <div><?php echo $type; ?></div>
        </div>
        <div class="pet-info-item" style="text-align: center;">
            <img src="images/icon-location-pin1.png" alt="Location Pin Icon" style="width: 30px; height: auto;">
            <div><?php echo $location; ?></div>
        </div>
    </div>

    <h2><?php echo $petname; ?></h2>
    <p class="description"><?php echo $description; ?></p>

    <div class="menu-links" id="menuLinks">
        <a href="index.php">Home</a>
        <a href="pets.php">Pets</a>
        <a href="gallery.php">Gallery</a>
        <a href="add.php">Add a pet</a>
    </div>
</div>

<script src="./js/main.js"></script>
<?php include('include/footer.inc'); ?>
