<!-- ############################################################# TEST ################################################################# -->

<?php
function validateInput($str)
{
    $ret = trim($str);
    return $ret;
}

foreach ($_POST as $key => $value){
    # code...
    $$key = validateInput($value);
}

include('include/db_connect.inc');

$sql = "INSERT INTO pets (petname, description, image, caption, age, location, type) VALUES (?,?,?,?,?,?,?)";

$stmt = $conn->prepare($sql);

$stmt->bind_param("ssssiss", $petname, $description, $image, $caption, $age, $location ,$type);

$stmt->execute();
$conn->close();
if ($stmt->affected_rows > 0) {
    if (!empty($_FILES['file01'])) {
        $tmp = $_FILES['file01']['tmp_name'];
        $dest = "uploadedFiles/{$_FILES['file01']['name']}"; // uploadedFiles is the folder name created in the current library folder
        move_uploaded_file($tmp, $dest);
    }
    //back to home
    header("Location:index.php");
    exit(0);
} else {
    echo "An error has occured!";
}
?>

<?php
    include('include/footer.inc')
    ?>
    <!-- ############################################################################################################################################ -->

</html>